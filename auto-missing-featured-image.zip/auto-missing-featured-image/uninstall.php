<?php
/**
 * Uninstall handler: remove plugin options.
 * Images already added to the Media Library are intentionally kept,
 * because posts may still be using them as featured images.
 *
 * @package Auto_Missing_Featured_Image
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'amfi_settings' );
