=== Auto Missing Featured Image – Unsplash, Pexels & AI ===
Contributors: yourusername
Tags: featured image, thumbnail, Unsplash, Pexels, AI, bulk, media
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically find posts without a featured image and set one from Unsplash or Pexels based on the title, with optional Groq AI keyword optimization.

== Description ==

**Auto Missing Featured Image** scans your posts, pages, WooCommerce products, or any custom post type for entries that are missing a featured image — then finds and sets a relevant free stock photo automatically based on the post title.

**Key features**

* Finds every post missing a featured image, for any post type and post status you choose
* Searches **Unsplash** and **Pexels** (both free) using the post title
* Dashboard-style Unsplash credential fields (Application ID / Access Key / Secret Key) with show/hide toggles and one-click **Test Connection** buttons for Unsplash, Pexels and Groq, including remaining rate-limit info and helpful 401 hints
* Medium quality image (~1000px) by default — fast pages, sharp thumbnails; Small / Large / Original also available
* Landscape, portrait, square, or any orientation
* **Batch processing one post at a time** in your browser, with live progress bar and log — never overloads your server or the APIs
* **Manual picker:** click "Find Images" on any post, adjust keywords, and click the photo you like
* **Editor meta box:** search and set a featured image without leaving the post editor
* Images are **downloaded into your Media Library** (never hotlinked), with automatic alt text and photographer credit
* Existing featured images are never overwritten (unless you disable that protection)
* **Optional Groq AI:** converts any title — long or non-English titles included — into the best English stock-search keywords, one AI request per post
* **Optional Grok (xAI) generation:** if no stock photo matches at all, generate one with AI (requires a paid xAI key)
* Smart fallbacks: shortened-title search, AI keywords, your own fallback query, then AI generation
* Source priority: if one stock API reaches its hourly limit, the other is used automatically

Free API keys (2-minute setup, full instructions in the plugin's Help tab): Unsplash Developers, Pexels API, and optionally Groq Console.

== Installation ==

1. Upload the `auto-missing-featured-image` folder to `/wp-content/plugins/`, or install through the WordPress Plugins screen.
2. Activate the plugin.
3. Go to **Auto Featured Image → Settings & API Keys** and paste your free Unsplash and/or Pexels keys. Optionally add a Groq AI key for smarter keywords.
4. Choose post types, statuses, image quality, and orientation. Save.
5. Open **Scan & Process**, select posts, and run the batch — or use "Find Images" per post to pick photos manually.

== External services ==

This plugin connects to external APIs only when an administrator runs a search or batch, and only for services whose API key the administrator has entered in the plugin settings. No data is sent automatically, and no data about site visitors is ever sent.

* **Unsplash API** (api.unsplash.com) – used to search free stock photos. Only the search query (derived from the post title or typed by the admin) is sent. Terms of Service: https://unsplash.com/terms – Privacy Policy: https://unsplash.com/privacy
* **Pexels API** (api.pexels.com) – used to search free stock photos. Only the search query is sent. Terms of Service: https://www.pexels.com/terms-of-service/ – Privacy Policy: https://www.pexels.com/privacy-policy/
* **Groq AI** (api.groq.com, optional) – used to turn a post title into stock-search keywords. The post title, a short excerpt, and category/tag names are sent. Terms of Service: https://groq.com/terms-of-use – Privacy Policy: https://groq.com/privacy-policy/
* **xAI (Grok)** (api.x.ai, optional) – used to generate an image when no stock photo is found. A short image prompt derived from the post title is sent. Terms of Service: https://x.ai/legal/terms-of-service – Privacy Policy: https://x.ai/legal/privacy-policy

API keys are stored only in your own WordPress options table and are never sent anywhere except to their respective service.

== Frequently Asked Questions ==

= Are the images free to use? =

Unsplash and Pexels photos are free to use under their licenses (attribution appreciated, not required — this plugin adds the photographer credit to the image caption by default). Always review the license of the service you use. Trademarks, logos, and depictions of people may have additional restrictions.

= Are images hotlinked from Unsplash/Pexels? =

No. Every image is downloaded into your own Media Library and set as a normal WordPress featured image, so it keeps working even if you remove this plugin.

= My titles are not in English. Will it still find good photos? =

Yes — enable Groq AI and set it to "Always". It reads your title/excerpt and returns English search keywords that stock APIs understand.

= Will it overwrite existing featured images? =

No, not by default. The plugin only lists and processes posts that have no featured image.

= What are the API limits? =

Unsplash demo apps allow roughly 50 requests/hour, Pexels roughly 200 requests/hour (free tiers; limits may change). Because the plugin can use both services and processes one post at a time, most sites can complete a few hundred posts in one session. Already-processed posts are skipped automatically, so you can simply continue a batch later.

= Does Groq AI generate the images? =

No. Groq provides fast language-model inference, not image generation. In this plugin it produces better search keywords. True AI image generation is available optionally through the separate xAI (Grok) integration.

= Does it work with WooCommerce products and custom post types? =

Yes. Any public post type that supports featured images can be enabled in Settings.

== Screenshots ==

1. Scan & Process: every post missing a featured image, with one-by-one batch processing and live progress.
2. Manual picker: search Unsplash/Pexels and click the photo you like.
3. Settings: API keys, quality, orientation, AI options, and post type selection.
4. Editor meta box: find a featured image without leaving the post editor.

== Changelog ==

= 1.1.0 =
* Unsplash settings now mirror the Unsplash application page: separate Application ID, Access Key and Secret Key fields (only the Access Key is used for searching, per the Unsplash docs).
* Added "Test Connection" buttons for Unsplash, Pexels and Groq. They verify a key before saving, show remaining rate limits, and explain 401 errors (e.g. Secret Key pasted instead of Access Key).
* Show/hide (eye) toggles on all API key fields.
* Groq model field now suggests current models and links to console.groq.com/docs and /docs/models; the Groq integration follows the official OpenAI-compatible endpoint documented there.
* Refreshed, prettier admin UI (cards, badges, gradients, improved table, modal and progress log).

= 1.0.0 =
* Initial release: missing featured image scanner, Unsplash + Pexels search, batch and manual modes, editor meta box, Groq AI keyword optimization, optional Grok (xAI) generation fallback.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
