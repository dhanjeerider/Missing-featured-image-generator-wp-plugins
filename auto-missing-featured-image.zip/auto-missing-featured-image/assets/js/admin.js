/**
 * Auto Missing Featured Image – admin interactions.
 * Batch processing is intentionally sequential (one post at a time)
 * so API limits and the server are never overloaded.
 */
(function ($) {
    'use strict';

    var i18n = (window.amfiData && amfiData.i18n) ? amfiData.i18n : {};
    var state = {
        queue: [],
        index: 0,
        success: 0,
        failed: 0,
        skipped: 0,
        stopped: false,
        running: false,
        modalPostId: 0
    };

    function ajax(action, data) {
        data = data || {};
        data.action = action;
        data._ajax_nonce = amfiData.nonce;
        return $.post(amfiData.ajaxUrl, data);
    }

    function escHtml(str) {
        return String(str || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function errorMessage(response) {
        if (response && response.data && response.data.message) {
            return response.data.message;
        }
        return i18n.errorGeneric || 'Error';
    }

    /* --------------------------------------------------------------
     * Manual picker (shared by the modal and the editor meta box)
     * -------------------------------------------------------------- */

    function renderResults($grid, items, postId, onSet) {
        $grid.empty();
        if (!items || !items.length) {
            $grid.html('<p class="description">' + escHtml(i18n.noResults) + '</p>');
            return;
        }
        items.forEach(function (item) {
            var credit = item.photographer ? ('📷 ' + item.photographer + ' · ' + item.source) : item.source;
            var $card = $(
                '<figure class="amfi-card" tabindex="0">' +
                    '<img loading="lazy" alt="">' +
                    '<figcaption></figcaption>' +
                    '<button type="button" class="button button-primary button-small amfi-set-btn">Set Featured</button>' +
                '</figure>'
            );
            $card.find('img').attr('src', item.thumb_url).attr('alt', item.alt || '');
            $card.find('figcaption').text(credit);

            $card.find('.amfi-set-btn').on('click', function () {
                if (!window.confirm(i18n.confirmSet)) {
                    return;
                }
                var $btn = $(this).prop('disabled', true).text(i18n.setting);
                ajax('amfi_set_from_url', {
                    post_id: postId,
                    full_url: item.full_url,
                    source: item.source,
                    alt: item.alt || '',
                    photographer: item.photographer || '',
                    photographer_url: item.photographer_url || '',
                    page_url: item.page_url || '',
                    download_location: item.download_location || ''
                }).done(function (res) {
                    if (res && res.success) {
                        $card.addClass('amfi-card-done');
                        if (typeof onSet === 'function') {
                            onSet(res.data);
                        }
                    } else {
                        $btn.prop('disabled', false).text('Set Featured');
                        window.alert(errorMessage(res));
                    }
                }).fail(function () {
                    $btn.prop('disabled', false).text('Set Featured');
                    window.alert(i18n.errorGeneric);
                });
            });

            $grid.append($card);
        });
    }

    function searchImages(postId, query, $grid, $status, useAi, onSet) {
        $status.text(useAi ? i18n.aiThinking : i18n.searching);
        $grid.empty();
        ajax('amfi_search_images', {
            post_id: postId,
            query: query,
            use_ai: useAi ? 1 : 0
        }).done(function (res) {
            if (res && res.success) {
                $status.text('Keywords: "' + res.data.query + '" — ' + res.data.items.length + ' result(s). Click an image.');
                renderResults($grid, res.data.items, postId, onSet);
            } else {
                $status.text(errorMessage(res));
            }
        }).fail(function () {
            $status.text(i18n.errorGeneric);
        });
    }

    /* --------------------------------------------------------------
     * Modal (Scan & Process tab)
     * -------------------------------------------------------------- */

    var $modal = $('#amfi-modal');
    var $modalQuery = $('#amfi-modal-query');
    var $modalResults = $('#amfi-modal-results');
    var $modalStatus = $('#amfi-modal-status');

    function openModal(postId, title) {
        state.modalPostId = postId;
        $('#amfi-modal-for').text('— #' + postId);
        $modalQuery.val(title || '');
        $modalResults.empty();
        $modalStatus.text('');
        $modal.show();
        searchImages(postId, title || '', $modalResults, $modalStatus, false, function (data) {
            markRowSuccess(postId, data.image_url, 'Manual pick');
            $modal.hide();
        });
    }

    function closeModal() {
        $modal.hide();
    }

    $('.amfi-find-btn').on('click', function () {
        openModal(parseInt($(this).data('post-id'), 10), $(this).data('title'));
    });

    $('.amfi-modal-close').on('click', closeModal);
    $modal.on('click', function (e) {
        if (e.target === this) {
            closeModal();
        }
    });
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });

    $('#amfi-modal-search').on('click', function () {
        searchImages(state.modalPostId, $modalQuery.val(), $modalResults, $modalStatus, false, function (data) {
            markRowSuccess(state.modalPostId, data.image_url, 'Manual pick');
            $modal.hide();
        });
    });

    $modalQuery.on('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            $('#amfi-modal-search').trigger('click');
        }
    });

    $('#amfi-modal-ai').on('click', function () {
        $modalStatus.text(i18n.aiThinking);
        ajax('amfi_ai_query', { post_id: state.modalPostId }).done(function (res) {
            if (res && res.success) {
                $modalQuery.val(res.data.query);
                $('#amfi-modal-search').trigger('click');
            } else {
                $modalStatus.text(errorMessage(res));
            }
        }).fail(function () {
            $modalStatus.text(i18n.errorGeneric);
        });
    });

    /* --------------------------------------------------------------
     * Batch processing (one by one)
     * -------------------------------------------------------------- */

    function markRowSuccess(postId, imageUrl, note) {
        var $row = $('tr[data-post-id="' + postId + '"]');
        var html = '<span class="amfi-ok">✅ ' + escHtml(i18n.done) + '</span>';
        if (imageUrl) {
            html += '<br><img class="amfi-thumb" src="' + escHtml(imageUrl) + '" alt="">';
        }
        if (note) {
            html += '<br><small>' + escHtml(note) + '</small>';
        }
        $row.find('.amfi-row-result').html(html);
        $row.find('.amfi-check').prop('checked', false);
    }

    function markRowText(postId, text, isError) {
        var $row = $('tr[data-post-id="' + postId + '"]');
        $row.find('.amfi-row-result').html(
            '<span class="' + (isError ? 'amfi-err' : '') + '">' + escHtml(text) + '</span>'
        );
    }

    function logLine(text, cls) {
        $('#amfi-log').append('<li class="' + escHtml(cls || '') + '">' + escHtml(text) + '</li>');
    }

    function updateProgress() {
        var total = state.queue.length;
        var doneCount = state.index;
        var pct = total ? Math.round((doneCount / total) * 100) : 0;
        $('#amfi-progress-bar').css('width', pct + '%');
        $('#amfi-progress-text').text(
            doneCount + ' / ' + total + ' (' + pct + '%) · ✅ ' + state.success + ' · ❌ ' + state.failed + ' · ⏭ ' + state.skipped
        );
    }

    function processNext() {
        if (state.stopped) {
            finishBatch(i18n.batchStopped);
            return;
        }
        if (state.index >= state.queue.length) {
            finishBatch(i18n.batchDone);
            return;
        }

        var postId = state.queue[state.index];
        markRowText(postId, '⏳ ' + i18n.processing, false);

        ajax('amfi_process_one', { post_id: postId }).done(function (res) {
            state.index++;
            if (res && res.success) {
                var d = res.data;
                if (d.status === 'success') {
                    state.success++;
                    markRowSuccess(postId, d.image_url, (d.source || '') + (d.query_used ? ' · "' + d.query_used + '"' : ''));
                    logLine('✅ #' + postId + ' ' + (d.post_title || '') + ' → ' + (d.source || ''), 'amfi-ok');
                } else if (d.status === 'skipped') {
                    state.skipped++;
                    markRowText(postId, '⏭ ' + d.message, false);
                    logLine('⏭ #' + postId + ' ' + (d.post_title || '') + ' — ' + d.message, '');
                } else {
                    state.failed++;
                    markRowText(postId, '❌ ' + d.message, true);
                    logLine('❌ #' + postId + ' ' + (d.post_title || '') + ' — ' + d.message, 'amfi-err');
                }
            } else {
                state.failed++;
                markRowText(postId, '❌ ' + errorMessage(res), true);
                logLine('❌ #' + postId + ' — ' + errorMessage(res), 'amfi-err');
            }
            updateProgress();
            // Small pause between requests keeps things polite with the APIs.
            window.setTimeout(processNext, 400);
        }).fail(function () {
            state.index++;
            state.failed++;
            markRowText(postId, '❌ ' + i18n.errorGeneric, true);
            updateProgress();
            window.setTimeout(processNext, 400);
        });
    }

    function startBatch(ids) {
        if (state.running) {
            return;
        }
        if (!ids.length) {
            window.alert(i18n.noSelection);
            return;
        }
        state.queue = ids;
        state.index = 0;
        state.success = 0;
        state.failed = 0;
        state.skipped = 0;
        state.stopped = false;
        state.running = true;

        $('#amfi-progress-wrap').show();
        $('#amfi-log').empty();
        $('#amfi-stop-batch').show();
        $('#amfi-process-selected, #amfi-process-page').prop('disabled', true);
        updateProgress();
        processNext();
    }

    function finishBatch(message) {
        state.running = false;
        $('#amfi-stop-batch').hide();
        $('#amfi-process-selected, #amfi-process-page').prop('disabled', false);
        logLine('— ' + message + ' —', '');
        updateProgress();
    }

    function selectedIds() {
        var ids = [];
        $('.amfi-check:checked').each(function () {
            ids.push(parseInt($(this).val(), 10));
        });
        return ids;
    }

    function pageIds() {
        var ids = [];
        $('.amfi-table tbody tr[data-post-id]').each(function () {
            ids.push(parseInt($(this).data('post-id'), 10));
        });
        return ids;
    }

    $('#amfi-process-selected').on('click', function () {
        startBatch(selectedIds());
    });

    $('#amfi-process-page').on('click', function () {
        startBatch(pageIds());
    });

    $('#amfi-stop-batch').on('click', function () {
        state.stopped = true;
    });

    $('#amfi-check-all').on('change', function () {
        $('.amfi-check').prop('checked', $(this).prop('checked'));
    });

    /* Single "Auto Set" button on a row */
    $('.amfi-auto-one').on('click', function () {
        var postId = parseInt($(this).data('post-id'), 10);
        var $btn = $(this).prop('disabled', true).text(i18n.processing);
        markRowText(postId, '⏳ ' + i18n.processing, false);
        ajax('amfi_process_one', { post_id: postId }).done(function (res) {
            $btn.prop('disabled', false).text('Auto Set');
            if (res && res.success && res.data.status === 'success') {
                markRowSuccess(postId, res.data.image_url, (res.data.source || '') + ' · "' + (res.data.query_used || '') + '"');
            } else if (res && res.success) {
                markRowText(postId, res.data.message, res.data.status === 'failed');
            } else {
                markRowText(postId, errorMessage(res), true);
            }
        }).fail(function () {
            $btn.prop('disabled', false).text('Auto Set');
            markRowText(postId, i18n.errorGeneric, true);
        });
    });

    /* --------------------------------------------------------------
     * Settings: show / hide API keys + Test Connection buttons
     * -------------------------------------------------------------- */

    $(document).on('click', '.amfi-toggle-key', function () {
        var targetId = $(this).data('target');
        var $input = $('#' + targetId);
        var $icon = $(this).find('.dashicons');
        if (!$input.length) {
            return;
        }
        if ($input.attr('type') === 'password') {
            $input.attr('type', 'text');
            $icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
        } else {
            $input.attr('type', 'password');
            $icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
        }
    });

    $(document).on('click', '.amfi-test-btn', function () {
        var $btn = $(this);
        var service = $btn.data('service');
        var keyInputId = $btn.data('key-input');
        var modelInputId = $btn.data('model-input');
        var $cell = $btn.closest('td');
        var $result = $cell.find('.amfi-test-result').first();
        var apiKey = keyInputId ? $.trim($('#' + keyInputId).val() || '') : '';
        var model = modelInputId ? $.trim($('#' + modelInputId).val() || '') : '';
        var originalText = $btn.text();

        $btn.prop('disabled', true).text(i18n.testing || 'Testing…');
        $result.removeClass('is-ok is-err').text('');

        ajax('amfi_test_connection', {
            service: service,
            api_key: apiKey,
            model: model
        }).done(function (res) {
            if (res && res.success) {
                $result.addClass('is-ok').text('✅ ' + (res.data.message || 'OK'));
            } else {
                $result.addClass('is-err').text('❌ ' + errorMessage(res));
            }
        }).fail(function () {
            $result.addClass('is-err').text('❌ ' + (i18n.errorGeneric || 'Error'));
        }).always(function () {
            $btn.prop('disabled', false).text(originalText);
        });
    });

    /* --------------------------------------------------------------
     * Editor meta box
     * -------------------------------------------------------------- */

    $('.amfi-metabox').each(function () {
        var $box = $(this);
        var postId = parseInt($box.data('post-id'), 10);
        var $query = $box.find('.amfi-metabox-query');
        var $results = $box.find('.amfi-metabox-results');
        var $status = $box.find('.amfi-metabox-status');

        function afterSet() {
            $status.text('✅ ' + i18n.done + ' — reloading…');
            window.location.reload();
        }

        $box.find('.amfi-metabox-search').on('click', function () {
            searchImages(postId, $query.val(), $results, $status, false, afterSet);
        });

        $box.find('.amfi-metabox-ai').on('click', function () {
            $status.text(i18n.aiThinking);
            ajax('amfi_ai_query', { post_id: postId }).done(function (res) {
                if (res && res.success) {
                    $query.val(res.data.query);
                    searchImages(postId, res.data.query, $results, $status, false, afterSet);
                } else {
                    $status.text(errorMessage(res));
                }
            }).fail(function () {
                $status.text(i18n.errorGeneric);
            });
        });

        $box.find('.amfi-metabox-auto').on('click', function () {
            $status.text('⏳ ' + i18n.processing);
            ajax('amfi_process_one', { post_id: postId }).done(function (res) {
                if (res && res.success && res.data.status === 'success') {
                    afterSet();
                } else if (res && res.success) {
                    $status.text(res.data.message);
                } else {
                    $status.text(errorMessage(res));
                }
            }).fail(function () {
                $status.text(i18n.errorGeneric);
            });
        });
    });
})(jQuery);
