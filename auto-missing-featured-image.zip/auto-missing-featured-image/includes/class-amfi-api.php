<?php
/**
 * External API clients: Unsplash, Pexels, Groq AI and Grok (xAI).
 *
 * All requests use the WordPress HTTP API (wp_remote_*), which is the
 * wordpress.org-recommended way to call external services.
 *
 * @package Auto_Missing_Featured_Image
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AMFI_API
 */
class AMFI_API {

	/**
	 * Return the ordered list of stock sources from settings.
	 *
	 * @param array $settings Plugin settings.
	 * @return string[]
	 */
	public static function get_sources_order( $settings ) {
		switch ( isset( $settings['source_priority'] ) ? $settings['source_priority'] : '' ) {
			case 'pexels_then_unsplash':
				return array( 'pexels', 'unsplash' );
			case 'unsplash_only':
				return array( 'unsplash' );
			case 'pexels_only':
				return array( 'pexels' );
			case 'unsplash_then_pexels':
			default:
				return array( 'unsplash', 'pexels' );
		}
	}

	/**
	 * Search stock photos.
	 *
	 * @param string $query    Search query.
	 * @param array  $settings Plugin settings.
	 * @param int    $per_page Results per source.
	 * @param bool   $merge    True: merge all sources (manual picker).
	 *                         False: stop at first source with results (auto mode).
	 * @return array|WP_Error Normalized image items.
	 */
	public static function search_stock( $query, $settings, $per_page = 9, $merge = false ) {
		$query = trim( (string) $query );
		if ( '' === $query ) {
			return new WP_Error( 'amfi_empty_query', __( 'Search query is empty.', 'auto-missing-featured-image' ) );
		}

		$results = array();
		$errors  = array();

		foreach ( self::get_sources_order( $settings ) as $source ) {
			if ( 'unsplash' === $source ) {
				$items = self::search_unsplash( $query, $settings, $per_page );
			} else {
				$items = self::search_pexels( $query, $settings, $per_page );
			}

			if ( is_wp_error( $items ) ) {
				$errors[] = $source . ': ' . $items->get_error_message();
				continue;
			}

			if ( ! empty( $items ) ) {
				$results = array_merge( $results, $items );
				if ( ! $merge ) {
					break;
				}
			}
		}

		if ( empty( $results ) && ! empty( $errors ) ) {
			return new WP_Error( 'amfi_api_error', implode( ' | ', $errors ) );
		}

		return $results;
	}

	/**
	 * Search Unsplash.
	 *
	 * External service: https://unsplash.com/developers
	 * Data sent: the search query only.
	 *
	 * @param string $query    Search query.
	 * @param array  $settings Plugin settings.
	 * @param int    $per_page Results requested.
	 * @return array|WP_Error
	 */
	public static function search_unsplash( $query, $settings, $per_page = 9 ) {
		$key = isset( $settings['unsplash_key'] ) ? trim( (string) $settings['unsplash_key'] ) : '';
		if ( '' === $key ) {
			return new WP_Error( 'amfi_no_unsplash_key', __( 'Unsplash Access Key is not set.', 'auto-missing-featured-image' ) );
		}

		$args = array(
			'query'    => $query,
			'per_page' => max( 1, min( 30, absint( $per_page ) ) ),
			'page'     => 1,
		);

		if ( ! empty( $settings['orientation'] ) && 'any' !== $settings['orientation'] ) {
			$args['orientation'] = sanitize_key( $settings['orientation'] );
		}

		$url      = add_query_arg( $args, 'https://api.unsplash.com/search/photos' );
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Client-ID ' . $key,
					'Accept'        => 'application/json',
					'Accept-Version' => 'v1',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg = ( isset( $body['errors'][0] ) ) ? (string) $body['errors'][0] : 'HTTP ' . $code;
			if ( 401 === $code || 403 === $code ) {
				$msg .= ' — ' . __( 'Invalid Access Key. Make sure you pasted the ACCESS KEY (not the Secret Key or Application ID) from your Unsplash application page.', 'auto-missing-featured-image' );
			}
			if ( 429 === $code ) {
				$msg .= ' — ' . __( 'Hourly rate limit reached. Wait a while or let the plugin use the other source.', 'auto-missing-featured-image' );
			}
			return new WP_Error( 'amfi_unsplash_http', __( 'Unsplash error: ', 'auto-missing-featured-image' ) . $msg );
		}

		$quality_map = array(
			'small'    => 'small',
			'medium'   => 'regular', // ~1080px wide: ideal featured-image size.
			'large'    => 'full',
			'original' => 'raw',
		);
		$quality = isset( $quality_map[ $settings['quality'] ] ) ? $quality_map[ $settings['quality'] ] : 'regular';

		$items = array();
		if ( ! empty( $body['results'] ) && is_array( $body['results'] ) ) {
			foreach ( $body['results'] as $photo ) {
				if ( empty( $photo['urls'] ) ) {
					continue;
				}
				$full_url = isset( $photo['urls'][ $quality ] ) ? $photo['urls'][ $quality ] : $photo['urls']['regular'];
				$items[]  = array(
					'source'            => 'unsplash',
					'id'                => (string) $photo['id'],
					'full_url'          => esc_url_raw( $full_url ),
					'thumb_url'         => esc_url_raw( isset( $photo['urls']['small'] ) ? $photo['urls']['small'] : $photo['urls']['thumb'] ),
					'alt'               => sanitize_text_field( self::first_not_empty( $photo, array( 'alt_description', 'description' ) ) ),
					'photographer'      => sanitize_text_field( isset( $photo['user']['name'] ) ? $photo['user']['name'] : '' ),
					'photographer_url'  => esc_url_raw( isset( $photo['user']['links']['html'] ) ? $photo['user']['links']['html'] : '' ),
					'page_url'          => esc_url_raw( isset( $photo['links']['html'] ) ? $photo['links']['html'] : '' ),
					'download_location' => esc_url_raw( isset( $photo['links']['download_location'] ) ? $photo['links']['download_location'] : '' ),
					'width'             => absint( isset( $photo['width'] ) ? $photo['width'] : 0 ),
					'height'            => absint( isset( $photo['height'] ) ? $photo['height'] : 0 ),
				);
			}
		}

		return $items;
	}

	/**
	 * Search Pexels.
	 *
	 * External service: https://www.pexels.com/api/
	 * Data sent: the search query only.
	 *
	 * @param string $query    Search query.
	 * @param array  $settings Plugin settings.
	 * @param int    $per_page Results requested.
	 * @return array|WP_Error
	 */
	public static function search_pexels( $query, $settings, $per_page = 9 ) {
		$key = isset( $settings['pexels_key'] ) ? trim( (string) $settings['pexels_key'] ) : '';
		if ( '' === $key ) {
			return new WP_Error( 'amfi_no_pexels_key', __( 'Pexels API Key is not set.', 'auto-missing-featured-image' ) );
		}

		$args = array(
			'query'    => $query,
			'per_page' => max( 1, min( 80, absint( $per_page ) ) ),
			'page'     => 1,
		);

		if ( ! empty( $settings['orientation'] ) && in_array( $settings['orientation'], array( 'landscape', 'portrait', 'squarish' ), true ) ) {
			$args['orientation'] = ( 'squarish' === $settings['orientation'] ) ? 'square' : sanitize_key( $settings['orientation'] );
		}

		$url      = add_query_arg( $args, 'https://api.pexels.com/v1/search' );
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => $key,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg = isset( $body['error'] ) ? (string) $body['error'] : 'HTTP ' . $code;
			return new WP_Error( 'amfi_pexels_http', __( 'Pexels error: ', 'auto-missing-featured-image' ) . $msg );
		}

		// "medium" maps to Pexels "large" (~940px), a good featured-image size.
		$quality_map = array(
			'small'    => 'medium',
			'medium'   => 'large',
			'large'    => 'large2x',
			'original' => 'original',
		);
		$quality = isset( $quality_map[ $settings['quality'] ] ) ? $quality_map[ $settings['quality'] ] : 'large';

		$items = array();
		if ( ! empty( $body['photos'] ) && is_array( $body['photos'] ) ) {
			foreach ( $body['photos'] as $photo ) {
				if ( empty( $photo['src'] ) ) {
					continue;
				}
				$full_url = isset( $photo['src'][ $quality ] ) ? $photo['src'][ $quality ] : $photo['src']['large'];
				$items[]  = array(
					'source'            => 'pexels',
					'id'                => (string) $photo['id'],
					'full_url'          => esc_url_raw( $full_url ),
					'thumb_url'         => esc_url_raw( isset( $photo['src']['medium'] ) ? $photo['src']['medium'] : $photo['src']['small'] ),
					'alt'               => sanitize_text_field( isset( $photo['alt'] ) ? $photo['alt'] : '' ),
					'photographer'      => sanitize_text_field( isset( $photo['photographer'] ) ? $photo['photographer'] : '' ),
					'photographer_url'  => esc_url_raw( isset( $photo['photographer_url'] ) ? $photo['photographer_url'] : '' ),
					'page_url'          => esc_url_raw( isset( $photo['url'] ) ? $photo['url'] : '' ),
					'download_location' => '',
					'width'             => absint( isset( $photo['width'] ) ? $photo['width'] : 0 ),
					'height'            => absint( isset( $photo['height'] ) ? $photo['height'] : 0 ),
				);
			}
		}

		return $items;
	}

	/**
	 * Ask Groq AI for the best English stock-photo search query for a post.
	 *
	 * Groq (groq.com) serves fast LLM inference; it does NOT generate images.
	 * It is used here to turn any title — including long or non-English
	 * titles — into 2–5 English keywords that stock APIs understand well.
	 * Calls are made one post at a time during batch processing.
	 *
	 * External service: https://console.groq.com/
	 * Data sent: post title, short excerpt, category/tag names.
	 *
	 * @param WP_Post $post     The post.
	 * @param array   $settings Plugin settings.
	 * @return string|WP_Error The search query.
	 */
	public static function Groq_optimize_query( $post, $settings ) {
		$key = isset( $settings['groq_key'] ) ? trim( (string) $settings['groq_key'] ) : '';
		if ( '' === $key ) {
			return new WP_Error( 'amfi_no_groq_key', __( 'Groq API key is not set.', 'auto-missing-featured-image' ) );
		}

		$title   = wp_strip_all_tags( get_the_title( $post ) );
		$excerpt = has_excerpt( $post ) ? $post->post_excerpt : wp_trim_words( wp_strip_all_tags( $post->post_content ), 40, '' );

		$term_names = array();
		foreach ( array( 'category', 'post_tag' ) as $tax ) {
			$terms = get_the_terms( $post->ID, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$term_names[] = $term->name;
				}
			}
		}

		$user_prompt = "Post title: {$title}\n";
		if ( $excerpt ) {
			$user_prompt .= "Excerpt: {$excerpt}\n";
		}
		if ( $term_names ) {
			$user_prompt .= 'Categories/Tags: ' . implode( ', ', array_slice( $term_names, 0, 6 ) ) . "\n";
		}

		$model   = ! empty( $settings['groq_model'] ) ? sanitize_text_field( $settings['groq_model'] ) : 'llama-3.3-70b-versatile';
		$payload = array(
			'model'       => $model,
			'temperature' => 0.3,
			'max_tokens'  => 30,
			'messages'    => array(
				array(
					'role'    => 'system',
					'content' => 'You are a stock photography search expert. Given a blog post title (it may be in Hindi or any language), reply with ONLY a 2 to 5 word English stock photo search query that best represents the topic visually. No quotes, no punctuation, no explanation.',
				),
				array(
					'role'    => 'user',
					'content' => $user_prompt,
				),
			),
		);

		$response = wp_remote_post(
			'https://api.groq.com/openai/v1/chat/completions',
			array(
				'timeout' => 25,
				'headers' => array(
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || empty( $body['choices'][0]['message']['content'] ) ) {
			$msg = isset( $body['error']['message'] ) ? (string) $body['error']['message'] : 'HTTP ' . $code;
			return new WP_Error( 'amfi_groq_http', __( 'Groq AI error: ', 'auto-missing-featured-image' ) . $msg );
		}

		$query = trim( (string) $body['choices'][0]['message']['content'] );
		$query = trim( $query, "\"'." );
		$query = sanitize_text_field( $query );

		// Keep at most 6 words; stock APIs work best with short queries.
		$words = preg_split( '/\s+/', $query );
		if ( is_array( $words ) && count( $words ) > 6 ) {
			$query = implode( ' ', array_slice( $words, 0, 6 ) );
		}

		if ( '' === $query ) {
			return new WP_Error( 'amfi_groq_empty', __( 'Groq AI returned an empty query.', 'auto-missing-featured-image' ) );
		}

		return $query;
	}

	/**
	 * Generate an image with Grok (xAI) — optional last-resort fallback.
	 *
	 * External service: https://x.ai/ (requires an xAI API key, "xai-…").
	 * Data sent: a short image prompt derived from the post title.
	 *
	 * @param WP_Post $post     The post.
	 * @param array   $settings Plugin settings.
	 * @return array|WP_Error One normalized image item.
	 */
	public static function grok_generate_image( $post, $settings ) {
		$key = isset( $settings['xai_key'] ) ? trim( (string) $settings['xai_key'] ) : '';
		if ( '' === $key ) {
			return new WP_Error( 'amfi_no_xai_key', __( 'xAI (Grok) API key is not set.', 'auto-missing-featured-image' ) );
		}

		$title  = wp_strip_all_tags( get_the_title( $post ) );
		$prompt = 'Blog featured image, wide 16:9 composition, clean professional illustration/photo style, no text, no watermark. Topic: ' . $title;
		$model  = ! empty( $settings['xai_model'] ) ? sanitize_text_field( $settings['xai_model'] ) : 'grok-2-image-1212';

		$response = wp_remote_post(
			'https://api.x.ai/v1/images/generations',
			array(
				'timeout' => 60,
				'headers' => array(
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'model'           => $model,
						'prompt'          => $prompt,
						'n'               => 1,
						'response_format' => 'url',
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || empty( $body['data'][0]['url'] ) ) {
			$msg = isset( $body['error'] ) ? (string) $body['error'] : 'HTTP ' . $code;
			return new WP_Error( 'amfi_xai_http', __( 'Grok (xAI) error: ', 'auto-missing-featured-image' ) . $msg );
		}

		return array(
			'source'            => 'grok-ai',
			'id'                => '',
			'full_url'          => esc_url_raw( $body['data'][0]['url'] ),
			'thumb_url'         => esc_url_raw( $body['data'][0]['url'] ),
			'alt'               => sanitize_text_field( $title ),
			'photographer'      => 'Grok AI (xAI)',
			'photographer_url'  => '',
			'page_url'          => '',
			'download_location' => '',
			'width'             => 0,
			'height'            => 0,
		);
	}

	/**
	 * Test an Unsplash Access Key without doing a real search.
	 *
	 * Uses the documented public authentication:
	 * Authorization: Client-ID YOUR_ACCESS_KEY
	 * (The Application ID and Secret Key are NOT used for searching;
	 * the secret is only for OAuth user-authorization flows.)
	 *
	 * @param string $access_key Unsplash Access Key.
	 * @return array|WP_Error Array with 'message' on success.
	 */
	public static function test_unsplash( $access_key ) {
		$access_key = trim( (string) $access_key );
		if ( '' === $access_key ) {
			return new WP_Error( 'amfi_test_empty', __( 'Paste the Unsplash Access Key first, then test.', 'auto-missing-featured-image' ) );
		}

		$response = wp_remote_get(
			add_query_arg( 'per_page', 1, 'https://api.unsplash.com/photos' ),
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization'  => 'Client-ID ' . $access_key,
					'Accept'         => 'application/json',
					'Accept-Version' => 'v1',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 !== $code ) {
			$hint = ( 401 === $code || 403 === $code )
				? __( 'Key rejected. Copy the value under "Access Key" on your Unsplash application page — not the Secret Key and not the Application ID.', 'auto-missing-featured-image' )
				: 'HTTP ' . $code;
			return new WP_Error( 'amfi_test_unsplash', $hint );
		}

		$remaining = (string) wp_remote_retrieve_header( $response, 'x-ratelimit-remaining' );
		$limit     = (string) wp_remote_retrieve_header( $response, 'x-ratelimit-limit' );
		$message   = __( 'Unsplash Access Key is working!', 'auto-missing-featured-image' );
		if ( '' !== $remaining ) {
			$message .= ' ' . sprintf(
				/* translators: 1: remaining requests, 2: total hourly limit. */
				__( '(Rate limit: %1$s of %2$s requests left this hour.)', 'auto-missing-featured-image' ),
				$remaining,
				'' !== $limit ? $limit : '?'
			);
		}

		return array( 'message' => $message );
	}

	/**
	 * Test a Pexels API key.
	 *
	 * @param string $api_key Pexels API key.
	 * @return array|WP_Error
	 */
	public static function test_pexels( $api_key ) {
		$api_key = trim( (string) $api_key );
		if ( '' === $api_key ) {
			return new WP_Error( 'amfi_test_empty', __( 'Paste the Pexels API Key first, then test.', 'auto-missing-featured-image' ) );
		}

		$response = wp_remote_get(
			add_query_arg(
				array(
					'query'    => 'nature',
					'per_page' => 1,
				),
				'https://api.pexels.com/v1/search'
			),
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => $api_key,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 !== $code ) {
			$hint = ( 401 === $code || 403 === $code )
				? __( 'Key rejected. Copy the key from pexels.com/api ("Your API Key") exactly, without spaces.', 'auto-missing-featured-image' )
				: 'HTTP ' . $code;
			return new WP_Error( 'amfi_test_pexels', $hint );
		}

		$remaining = (string) wp_remote_retrieve_header( $response, 'x-ratelimit-remaining' );
		$limit     = (string) wp_remote_retrieve_header( $response, 'x-ratelimit-limit' );
		$message   = __( 'Pexels API Key is working!', 'auto-missing-featured-image' );
		if ( '' !== $remaining ) {
			$message .= ' ' . sprintf(
				/* translators: 1: remaining requests, 2: total limit. */
				__( '(Rate limit: %1$s of %2$s requests left.)', 'auto-missing-featured-image' ),
				$remaining,
				'' !== $limit ? $limit : '?'
			);
		}

		return array( 'message' => $message );
	}

	/**
	 * Test a Groq API key via the models endpoint (no chat tokens used).
	 *
	 * Docs: https://console.groq.com/docs
	 * Keys: https://console.groq.com/keys
	 *
	 * @param string $api_key Groq API key ("gsk_…").
	 * @param string $model   Selected model ID to look for (optional).
	 * @return array|WP_Error
	 */
	public static function test_groq( $api_key, $model = '' ) {
		$api_key = trim( (string) $api_key );
		if ( '' === $api_key ) {
			return new WP_Error( 'amfi_test_empty', __( 'Paste the Groq API Key first, then test.', 'auto-missing-featured-image' ) );
		}

		$response = wp_remote_get(
			'https://api.groq.com/openai/v1/models',
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$hint = isset( $body['error']['message'] ) ? (string) $body['error']['message'] : 'HTTP ' . $code;
			if ( 401 === $code ) {
				$hint .= ' — ' . __( 'Create a new key at console.groq.com/keys (starts with "gsk_").', 'auto-missing-featured-image' );
			}
			return new WP_Error( 'amfi_test_groq', $hint );
		}

		$ids = array();
		if ( ! empty( $body['data'] ) && is_array( $body['data'] ) ) {
			foreach ( $body['data'] as $row ) {
				if ( ! empty( $row['id'] ) ) {
					$ids[] = (string) $row['id'];
				}
			}
		}

		$message = __( 'Groq API Key is working!', 'auto-missing-featured-image' );
		if ( $ids ) {
			$message .= ' ' . sprintf(
				/* translators: %d: number of available models. */
				__( '(%d models available on your account.)', 'auto-missing-featured-image' ),
				count( $ids )
			);
		}

		$model = trim( (string) $model );
		if ( '' !== $model && $ids && ! in_array( $model, $ids, true ) ) {
			$message .= ' ' . sprintf(
				/* translators: %s: model id. */
				__( 'Note: the selected model "%s" was not found in your account list — pick one from console.groq.com/docs/models.', 'auto-missing-featured-image' ),
				$model
			);
		}

		return array( 'message' => $message );
	}

	/**
	 * Ping the Unsplash download endpoint (required by the Unsplash API
	 * guidelines when a photo is actually used). Fire-and-forget.
	 *
	 * @param string $download_location download_location URL from the API.
	 * @param array  $settings          Plugin settings.
	 */
	public static function ping_unsplash_download( $download_location, $settings ) {
		if ( '' === (string) $download_location || empty( $settings['unsplash_key'] ) ) {
			return;
		}
		wp_remote_get(
			$download_location,
			array(
				'timeout'  => 5,
				'blocking' => false,
				'headers'  => array(
					'Authorization' => 'Client-ID ' . trim( (string) $settings['unsplash_key'] ),
				),
			)
		);
	}

	/**
	 * Return the first non-empty value among the given keys.
	 *
	 * @param array $arr  Source array.
	 * @param array $keys Keys to try, in order.
	 * @return string
	 */
	private static function first_not_empty( $arr, $keys ) {
		foreach ( $keys as $k ) {
			if ( ! empty( $arr[ $k ] ) ) {
				return (string) $arr[ $k ];
			}
		}
		return '';
	}
}
