<?php
/**
 * Finds posts without a featured image and sideloads one into the
 * Media Library, then sets it as the post thumbnail.
 *
 * @package Auto_Missing_Featured_Image
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AMFI_Processor
 */
class AMFI_Processor {

	/**
	 * Count posts missing a featured image.
	 *
	 * @param array $settings Plugin settings.
	 * @return int
	 */
	public static function count_missing( $settings ) {
		$query = self::missing_query(
			$settings,
			array(
				'posts_per_page' => 1,
				'paged'          => 1,
				'fields'         => 'ids',
			)
		);
		return (int) $query->found_posts;
	}

	/**
	 * Build a WP_Query for posts missing a featured image.
	 *
	 * @param array $settings  Plugin settings.
	 * @param array $overrides Extra WP_Query args (pagination, type filter, search…).
	 * @return WP_Query
	 */
	public static function missing_query( $settings, $overrides = array() ) {
		$args = array(
			'post_type'      => ! empty( $settings['post_types'] ) ? $settings['post_types'] : array( 'post' ),
			'post_status'    => ! empty( $settings['post_status'] ) ? $settings['post_status'] : array( 'publish' ),
			'posts_per_page' => 20,
			'orderby'        => 'date',
			'order'          => 'DESC',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required to find posts without a thumbnail.
			'meta_query'     => array(
				array(
					'key'     => '_thumbnail_id',
					'compare' => 'NOT EXISTS',
				),
			),
			'no_found_rows'  => false,
		);

		$args = array_merge( $args, $overrides );

		return new WP_Query( $args );
	}

	/**
	 * Build the first stock search query for a post from its title.
	 *
	 * @param WP_Post $post     The post.
	 * @param array   $settings Plugin settings.
	 * @return string
	 */
	public static function build_title_query( $post, $settings ) {
		$title = html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' );
		// Drop characters stock APIs dislike.
		$title = preg_replace( '/[^\p{L}\p{N}\s\-]+/u', ' ', $title );
		$title = trim( preg_replace( '/\s+/', ' ', (string) $title ) );

		$parts = array( $title );

		if ( isset( $settings['query_source'] ) && 'title_terms' === $settings['query_source'] ) {
			foreach ( array( 'category', 'post_tag' ) as $tax ) {
				$terms = get_the_terms( $post->ID, $tax );
				if ( $terms && ! is_wp_error( $terms ) ) {
					$parts[] = $terms[0]->name;
				}
			}
		}

		if ( ! empty( $settings['extra_keywords'] ) ) {
			$parts[] = sanitize_text_field( $settings['extra_keywords'] );
		}

		return trim( implode( ' ', $parts ) );
	}

	/**
	 * Fully process ONE post: find and set its featured image.
	 *
	 * Attempt order:
	 * 1. (Groq mode "always") AI keywords → stock search.
	 * 2. Full title → stock search.
	 * 3. Shortened title (first 5 words) → stock search.
	 * 4. (Groq mode "fallback") AI keywords → stock search, one AI request.
	 * 5. Admin-defined fallback query → stock search.
	 * 6. Optional Grok (xAI) AI image generation.
	 *
	 * @param int   $post_id  Post ID.
	 * @param array $settings Plugin settings.
	 * @return array Result: status (success|skipped|failed), message, query_used, source, image_url.
	 */
	public static function process_one( $post_id, $settings ) {
		$post_id = absint( $post_id );
		$post    = get_post( $post_id );

		if ( ! $post ) {
			return self::result( 'failed', __( 'Post not found.', 'auto-missing-featured-image' ) );
		}

		if ( ! empty( $settings['only_missing'] ) && has_post_thumbnail( $post_id ) ) {
			return self::result( 'skipped', __( 'Already has a featured image.', 'auto-missing-featured-image' ) );
		}

		$groq_mode  = isset( $settings['groq_mode'] ) ? $settings['groq_mode'] : 'fallback';
		$title_query = self::build_title_query( $post, $settings );
		$queries     = array();

		// 1. AI first, if mode is "always".
		if ( 'always' === $groq_mode && ! empty( $settings['groq_key'] ) ) {
			$ai_query = AMFI_API::Groq_optimize_query( $post, $settings );
			if ( ! is_wp_error( $ai_query ) && '' !== $ai_query ) {
				$queries[] = $ai_query;
			}
		}

		// 2 + 3. Title, then shortened title.
		if ( '' !== $title_query ) {
			$queries[] = $title_query;
			$words     = preg_split( '/\s+/', $title_query );
			if ( is_array( $words ) && count( $words ) > 5 ) {
				$queries[] = implode( ' ', array_slice( $words, 0, 5 ) );
			}
		}

		$queries = array_values( array_unique( array_filter( $queries ) ) );
		$found   = null;
		$used    = '';
		$errors  = array();

		foreach ( $queries as $q ) {
			$items = AMFI_API::search_stock( $q, $settings, 5, false );
			if ( is_wp_error( $items ) ) {
				$errors[] = $items->get_error_message();
				continue;
			}
			if ( ! empty( $items ) ) {
				$found = $items[0];
				$used  = $q;
				break;
			}
		}

		// 4. AI fallback: one Groq request for this post, then retry stock search.
		if ( ! $found && 'fallback' === $groq_mode && ! empty( $settings['groq_key'] ) ) {
			$ai_query = AMFI_API::Groq_optimize_query( $post, $settings );
			if ( is_wp_error( $ai_query ) ) {
				$errors[] = $ai_query->get_error_message();
			} elseif ( '' !== $ai_query && ! in_array( $ai_query, $queries, true ) ) {
				$items = AMFI_API::search_stock( $ai_query, $settings, 5, false );
				if ( ! is_wp_error( $items ) && ! empty( $items ) ) {
					$found = $items[0];
					$used  = $ai_query . ' (AI)';
				}
			}
		}

		// 5. Admin-defined fallback query.
		if ( ! $found && ! empty( $settings['fallback_query'] ) ) {
			$items = AMFI_API::search_stock( sanitize_text_field( $settings['fallback_query'] ), $settings, 20, false );
			if ( ! is_wp_error( $items ) && ! empty( $items ) ) {
				// Rotate through results so every post does not get the same photo.
				$pick  = $items[ $post_id % count( $items ) ];
				$found = $pick;
				$used  = $settings['fallback_query'] . ' (fallback)';
			}
		}

		// 6. Optional AI image generation with Grok (xAI).
		if ( ! $found && ! empty( $settings['ai_generate_fallback'] ) && ! empty( $settings['xai_key'] ) ) {
			$generated = AMFI_API::grok_generate_image( $post, $settings );
			if ( is_wp_error( $generated ) ) {
				$errors[] = $generated->get_error_message();
			} else {
				$found = $generated;
				$used  = 'AI Generated (Grok)';
			}
		}

		if ( ! $found ) {
			$msg = __( 'No image found for this title.', 'auto-missing-featured-image' );
			if ( $errors ) {
				$msg .= ' ' . implode( ' ', array_unique( $errors ) );
			}
			return self::result( 'failed', $msg );
		}

		$set = self::sideload_and_set( $post_id, $found, $settings );
		if ( is_wp_error( $set ) ) {
			return self::result( 'failed', $set->get_error_message() );
		}

		return array(
			'status'        => 'success',
			'message'       => __( 'Featured image set.', 'auto-missing-featured-image' ),
			'query_used'    => $used,
			'source'        => $found['source'],
			'attachment_id' => (int) $set,
			'image_url'     => (string) wp_get_attachment_image_url( $set, 'medium' ),
		);
	}

	/**
	 * Download a remote image into the Media Library and set it as thumbnail.
	 *
	 * Only URLs from the supported image CDNs are accepted by default; the
	 * list can be extended with the `amfi_allowed_image_hosts` filter.
	 *
	 * @param int   $post_id  Post ID.
	 * @param array $item     Normalized image item (see AMFI_API).
	 * @param array $settings Plugin settings.
	 * @return int|WP_Error Attachment ID on success.
	 */
	public static function sideload_and_set( $post_id, $item, $settings ) {
		$post_id = absint( $post_id );
		$url     = isset( $item['full_url'] ) ? esc_url_raw( $item['full_url'] ) : '';

		if ( '' === $url ) {
			return new WP_Error( 'amfi_no_url', __( 'Image URL is empty.', 'auto-missing-featured-image' ) );
		}

		if ( ! self::is_allowed_image_url( $url ) ) {
			return new WP_Error( 'amfi_host_not_allowed', __( 'Image host is not allowed.', 'auto-missing-featured-image' ) );
		}

		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$tmp = download_url( $url );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}

		$ext_from_url = strtolower( pathinfo( (string) wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		$allowed_exts = array( 'jpg', 'jpeg', 'png', 'webp' );
		if ( ! in_array( $ext_from_url, $allowed_exts, true ) ) {
			$ext_from_url = 'jpg';
		}

		$title_slug = sanitize_file_name( sanitize_title( get_the_title( $post_id ) ) );
		if ( '' === $title_slug ) {
			$title_slug = 'featured-image-' . $post_id;
		}

		$file_array = array(
			'name'     => $title_slug . '.' . $ext_from_url,
			'tmp_name' => $tmp,
		);

		$attachment_id = media_handle_sideload( $file_array, $post_id, get_the_title( $post_id ) );

		if ( is_wp_error( $attachment_id ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			return $attachment_id;
		}

		// Alt text for SEO/accessibility.
		if ( ! empty( $settings['set_alt_text'] ) ) {
			$alt = ! empty( $item['alt'] ) ? $item['alt'] : get_the_title( $post_id );
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
		}

		// Photographer credit in the caption (good practice for both APIs).
		if ( ! empty( $settings['add_credit'] ) && ! empty( $item['photographer'] ) ) {
			$source_label = ( 'unsplash' === $item['source'] ) ? 'Unsplash' : ( ( 'pexels' === $item['source'] ) ? 'Pexels' : 'AI' );
			wp_update_post(
				array(
					'ID'           => $attachment_id,
					'post_excerpt' => sprintf(
						/* translators: 1: photographer name, 2: source name. */
						__( 'Photo by %1$s on %2$s', 'auto-missing-featured-image' ),
						sanitize_text_field( $item['photographer'] ),
						$source_label
					),
				)
			);
		}

		// Remember where this image came from.
		update_post_meta( $attachment_id, '_amfi_source', sanitize_key( $item['source'] ) );
		if ( ! empty( $item['page_url'] ) ) {
			update_post_meta( $attachment_id, '_amfi_source_page_url', esc_url_raw( $item['page_url'] ) );
		}
		if ( ! empty( $item['photographer'] ) ) {
			update_post_meta( $attachment_id, '_amfi_photographer', sanitize_text_field( $item['photographer'] ) );
		}

		set_post_thumbnail( $post_id, $attachment_id );

		if ( 'unsplash' === $item['source'] && ! empty( $item['download_location'] ) ) {
			AMFI_API::ping_unsplash_download( $item['download_location'], $settings );
		}

		return (int) $attachment_id;
	}

	/**
	 * Check whether a remote image URL may be sideloaded.
	 *
	 * @param string $url Image URL.
	 * @return bool
	 */
	public static function is_allowed_image_url( $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );

		/**
		 * Filters the list of image hosts this plugin may download from.
		 *
		 * @param string[] $hosts Allowed hosts.
		 */
		$allowed = apply_filters(
			'amfi_allowed_image_hosts',
			array(
				'images.unsplash.com',
				'images.pexels.com',
				'imgen.x.ai',
				'cdn.x.ai',
			)
		);

		if ( in_array( $host, (array) $allowed, true ) ) {
			return true;
		}

		// xAI may serve generated images from sub-domains.
		if ( '.x.ai' === substr( $host, -5 ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Compact result helper.
	 *
	 * @param string $status  Status string.
	 * @param string $message Human-readable message.
	 * @return array
	 */
	private static function result( $status, $message ) {
		return array(
			'status'        => $status,
			'message'       => $message,
			'query_used'    => '',
			'source'        => '',
			'attachment_id' => 0,
			'image_url'     => '',
		);
	}
}
