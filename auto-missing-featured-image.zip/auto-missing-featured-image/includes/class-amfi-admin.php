<?php
/**
 * Admin UI: "Scan & Process" tab, Settings tab, Help tab,
 * post-edit-screen meta box and all AJAX handlers.
 *
 * @package Auto_Missing_Featured_Image
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AMFI_Admin
 */
class AMFI_Admin {

	/**
	 * Menu slug.
	 *
	 * @var string
	 */
	const MENU_SLUG = 'auto-missing-featured-image';

	/**
	 * Hook everything.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );

		add_action( 'wp_ajax_amfi_search_images', array( $this, 'ajax_search_images' ) );
		add_action( 'wp_ajax_amfi_process_one', array( $this, 'ajax_process_one' ) );
		add_action( 'wp_ajax_amfi_set_from_url', array( $this, 'ajax_set_from_url' ) );
		add_action( 'wp_ajax_amfi_ai_query', array( $this, 'ajax_ai_query' ) );
		add_action( 'wp_ajax_amfi_test_connection', array( $this, 'ajax_test_connection' ) );

		add_filter( 'plugin_action_links_' . plugin_basename( AMFI_FILE ), array( $this, 'action_links' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Menu & settings registration                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * Add the top-level admin menu.
	 */
	public function add_menu() {
		add_menu_page(
			__( 'Auto Featured Image', 'auto-missing-featured-image' ),
			__( 'Auto Featured Image', 'auto-missing-featured-image' ),
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_page' ),
			'dashicons-format-image',
			80
		);
	}

	/**
	 * Register the settings option.
	 */
	public function register_settings() {
		register_setting(
			'amfi_settings_group',
			'amfi_settings',
			array(
				'sanitize_callback' => array( $this, 'sanitize_settings' ),
				'default'           => amfi_default_settings(),
			)
		);
	}

	/**
	 * Sanitize all settings before saving.
	 *
	 * @param mixed $input Raw settings input.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		if ( ! is_array( $input ) ) {
			$input = array();
		}
		$clean = amfi_default_settings();

		// Plain text fields (API keys etc.).
		foreach ( array( 'unsplash_app_id', 'unsplash_key', 'unsplash_secret', 'pexels_key', 'groq_key', 'xai_key', 'groq_model', 'xai_model', 'extra_keywords', 'fallback_query' ) as $field ) {
			$clean[ $field ] = isset( $input[ $field ] ) ? sanitize_text_field( wp_unslash( $input[ $field ] ) ) : '';
		}

		// Select fields with fixed choices.
		$choices = array(
			'source_priority' => array( 'unsplash_then_pexels', 'pexels_then_unsplash', 'unsplash_only', 'pexels_only' ),
			'quality'         => array( 'small', 'medium', 'large', 'original' ),
			'orientation'     => array( 'any', 'landscape', 'portrait', 'squarish' ),
			'query_source'    => array( 'title', 'title_terms' ),
			'groq_mode'       => array( 'off', 'always', 'fallback' ),
		);
		foreach ( $choices as $field => $allowed ) {
			$value           = isset( $input[ $field ] ) ? sanitize_key( wp_unslash( $input[ $field ] ) ) : '';
			$clean[ $field ] = in_array( $value, $allowed, true ) ? $value : $clean[ $field ];
		}

		// Post types: only registered, public types (except attachments).
		$registered_types    = get_post_types( array( 'public' => true ) );
		unset( $registered_types['attachment'] );
		$types_in            = isset( $input['post_types'] ) && is_array( $input['post_types'] ) ? array_map( 'sanitize_key', wp_unslash( $input['post_types'] ) ) : array();
		$clean['post_types'] = array_values( array_intersect( $types_in, $registered_types ) );
		if ( empty( $clean['post_types'] ) ) {
			$clean['post_types'] = array( 'post' );
		}

		// Post statuses: only registered statuses.
		$registered_stati     = get_post_stati();
		$stati_in             = isset( $input['post_status'] ) && is_array( $input['post_status'] ) ? array_map( 'sanitize_key', wp_unslash( $input['post_status'] ) ) : array();
		$clean['post_status'] = array_values( array_intersect( $stati_in, $registered_stati ) );
		if ( empty( $clean['post_status'] ) ) {
			$clean['post_status'] = array( 'publish' );
		}

		// Numbers & checkboxes.
		$clean['batch_size']          = max( 1, min( 100, absint( isset( $input['batch_size'] ) ? $input['batch_size'] : 20 ) ) );
		$clean['only_missing']        = empty( $input['only_missing'] ) ? 0 : 1;
		$clean['set_alt_text']        = empty( $input['set_alt_text'] ) ? 0 : 1;
		$clean['add_credit']          = empty( $input['add_credit'] ) ? 0 : 1;
		$clean['ai_generate_fallback'] = empty( $input['ai_generate_fallback'] ) ? 0 : 1;

		return $clean;
	}

	/**
	 * Add a Settings link on the Plugins screen.
	 *
	 * @param array $links Existing action links.
	 * @return array
	 */
	public function action_links( $links ) {
		$url = add_query_arg(
			array(
				'page' => self::MENU_SLUG,
				'tab'  => 'settings',
			),
			admin_url( 'admin.php' )
		);
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'auto-missing-featured-image' ) . '</a>' );
		return $links;
	}

	/* ------------------------------------------------------------------ */
	/* Assets                                                              */
	/* ------------------------------------------------------------------ */

	/**
	 * Enqueue CSS/JS on the plugin screen and the post editor only.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		$on_plugin_page = ( 'toplevel_page_' . self::MENU_SLUG === $hook );
		$on_editor      = in_array( $hook, array( 'post.php', 'post-new.php' ), true );

		if ( ! $on_plugin_page && ! $on_editor ) {
			return;
		}

		wp_enqueue_style( 'amfi-admin', AMFI_URL . 'assets/css/admin.css', array(), AMFI_VERSION );
		wp_enqueue_script( 'amfi-admin', AMFI_URL . 'assets/js/admin.js', array( 'jquery' ), AMFI_VERSION, true );

		wp_localize_script(
			'amfi-admin',
			'amfiData',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'amfi_ajax' ),
				'i18n'    => array(
					'searching'    => __( 'Searching…', 'auto-missing-featured-image' ),
					'setting'      => __( 'Setting…', 'auto-missing-featured-image' ),
					'processing'   => __( 'Processing…', 'auto-missing-featured-image' ),
					'done'         => __( 'Done', 'auto-missing-featured-image' ),
					'failed'       => __( 'Failed', 'auto-missing-featured-image' ),
					'noResults'    => __( 'No images found. Try different keywords.', 'auto-missing-featured-image' ),
					'noSelection'  => __( 'Please select at least one post.', 'auto-missing-featured-image' ),
					'batchStopped' => __( 'Batch stopped by user.', 'auto-missing-featured-image' ),
					'batchDone'    => __( 'Batch complete.', 'auto-missing-featured-image' ),
					'confirmSet'   => __( 'Set this as the featured image?', 'auto-missing-featured-image' ),
					'aiThinking'   => __( 'Asking Groq AI…', 'auto-missing-featured-image' ),
					'testing'      => __( 'Testing…', 'auto-missing-featured-image' ),
					'showKey'      => __( 'Show', 'auto-missing-featured-image' ),
					'hideKey'      => __( 'Hide', 'auto-missing-featured-image' ),
					'errorGeneric' => __( 'Something went wrong. Check your API keys.', 'auto-missing-featured-image' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Main admin page                                                     */
	/* ------------------------------------------------------------------ */

	/**
	 * Render the tabbed admin page.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'auto-missing-featured-image' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab switch.
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'process';
		if ( ! in_array( $tab, array( 'process', 'settings', 'help' ), true ) ) {
			$tab = 'process';
		}

		$base_url = add_query_arg( 'page', self::MENU_SLUG, admin_url( 'admin.php' ) );
		?>
		<div class="wrap amfi-wrap">
			<h1><?php esc_html_e( 'Auto Missing Featured Image', 'auto-missing-featured-image' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Find posts without a featured image and set one automatically from Unsplash / Pexels using the post title — with optional Groq AI keyword help.', 'auto-missing-featured-image' ); ?></p>

			<nav class="nav-tab-wrapper">
				<a class="nav-tab <?php echo 'process' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tab', 'process', $base_url ) ); ?>"><?php esc_html_e( 'Scan & Process', 'auto-missing-featured-image' ); ?></a>
				<a class="nav-tab <?php echo 'settings' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tab', 'settings', $base_url ) ); ?>"><?php esc_html_e( 'Settings & API Keys', 'auto-missing-featured-image' ); ?></a>
				<a class="nav-tab <?php echo 'help' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tab', 'help', $base_url ) ); ?>"><?php esc_html_e( 'Help – How to get API keys', 'auto-missing-featured-image' ); ?></a>
			</nav>

			<div class="amfi-tab-body">
				<?php
				if ( 'settings' === $tab ) {
					$this->render_settings_tab();
				} elseif ( 'help' === $tab ) {
					$this->render_help_tab();
				} else {
					$this->render_process_tab();
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * "Scan & Process" tab.
	 */
	private function render_process_tab() {
		$settings  = amfi_get_settings();
		$base_url  = add_query_arg( 'page', self::MENU_SLUG, admin_url( 'admin.php' ) );
		$no_keys   = ( '' === trim( (string) $settings['unsplash_key'] ) && '' === trim( (string) $settings['pexels_key'] ) );

		// Filters (read-only GET params).
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$filter_type   = isset( $_GET['amfi_ptype'] ) ? sanitize_key( wp_unslash( $_GET['amfi_ptype'] ) ) : '';
		$search        = isset( $_GET['amfi_s'] ) ? sanitize_text_field( wp_unslash( $_GET['amfi_s'] ) ) : '';
		$current_page  = isset( $_GET['amfi_paged'] ) ? max( 1, absint( $_GET['amfi_paged'] ) ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$overrides = array(
			'posts_per_page' => max( 1, (int) $settings['batch_size'] ),
			'paged'          => $current_page,
		);
		if ( '' !== $filter_type && in_array( $filter_type, (array) $settings['post_types'], true ) ) {
			$overrides['post_type'] = $filter_type;
		}
		if ( '' !== $search ) {
			$overrides['s'] = $search;
		}

		$query        = AMFI_Processor::missing_query( $settings, $overrides );
		$total_missing = AMFI_Processor::count_missing( $settings );
		?>
		<div class="amfi-stats">
			<div class="amfi-stat-card">
				<strong><?php echo esc_html( number_format_i18n( $total_missing ) ); ?></strong>
				<span><?php esc_html_e( 'posts are missing a featured image (selected types & statuses)', 'auto-missing-featured-image' ); ?></span>
			</div>
			<div class="amfi-stat-card amfi-stat-settings">
				<span>
					<?php
					printf(
						/* translators: 1: image source mode, 2: quality, 3: AI mode. */
						esc_html__( 'Source: %1$s · Quality: %2$s · Groq AI: %3$s', 'auto-missing-featured-image' ),
						esc_html( str_replace( '_', ' ', $settings['source_priority'] ) ),
						esc_html( $settings['quality'] ),
						esc_html( $settings['groq_mode'] )
					);
					?>
				</span>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'settings', $base_url ) ); ?>"><?php esc_html_e( 'Change in Settings', 'auto-missing-featured-image' ); ?></a>
			</div>
		</div>

		<?php if ( $no_keys ) : ?>
			<div class="notice notice-warning inline">
				<p>
					<?php esc_html_e( 'No Unsplash or Pexels API key is set yet, so images cannot be searched.', 'auto-missing-featured-image' ); ?>
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'settings', $base_url ) ); ?>"><?php esc_html_e( 'Add your free API keys in Settings', 'auto-missing-featured-image' ); ?></a>
					<?php esc_html_e( '— see the Help tab for step-by-step instructions (takes 2 minutes).', 'auto-missing-featured-image' ); ?>
				</p>
			</div>
		<?php endif; ?>

		<form method="get" class="amfi-filters">
			<input type="hidden" name="page" value="<?php echo esc_attr( self::MENU_SLUG ); ?>">
			<input type="hidden" name="tab" value="process">
			<label>
				<?php esc_html_e( 'Post type', 'auto-missing-featured-image' ); ?>
				<select name="amfi_ptype">
					<option value=""><?php esc_html_e( 'All selected types', 'auto-missing-featured-image' ); ?></option>
					<?php foreach ( (array) $settings['post_types'] as $pt ) : ?>
						<?php $obj = get_post_type_object( $pt ); ?>
						<option value="<?php echo esc_attr( $pt ); ?>" <?php selected( $filter_type, $pt ); ?>><?php echo esc_html( $obj ? $obj->labels->name : $pt ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>
				<?php esc_html_e( 'Search title', 'auto-missing-featured-image' ); ?>
				<input type="search" name="amfi_s" value="<?php echo esc_attr( $search ); ?>">
			</label>
			<button class="button" type="submit"><?php esc_html_e( 'Filter', 'auto-missing-featured-image' ); ?></button>
		</form>

		<div class="amfi-batch-controls">
			<button type="button" class="button button-primary" id="amfi-process-selected"><?php esc_html_e( '▶ Auto-set for Selected (batch, one by one)', 'auto-missing-featured-image' ); ?></button>
			<button type="button" class="button" id="amfi-process-page"><?php esc_html_e( 'Auto-set All on This Page', 'auto-missing-featured-image' ); ?></button>
			<button type="button" class="button" id="amfi-stop-batch" style="display:none;"><?php esc_html_e( 'Stop', 'auto-missing-featured-image' ); ?></button>
		</div>

		<div id="amfi-progress-wrap" style="display:none;">
			<div class="amfi-progress"><div id="amfi-progress-bar"></div></div>
			<p id="amfi-progress-text"></p>
			<ul id="amfi-log"></ul>
		</div>

		<table class="widefat striped amfi-table">
			<thead>
				<tr>
					<td class="check-column"><input type="checkbox" id="amfi-check-all" aria-label="<?php esc_attr_e( 'Select all', 'auto-missing-featured-image' ); ?>"></td>
					<th><?php esc_html_e( 'ID', 'auto-missing-featured-image' ); ?></th>
					<th><?php esc_html_e( 'Title', 'auto-missing-featured-image' ); ?></th>
					<th><?php esc_html_e( 'Type', 'auto-missing-featured-image' ); ?></th>
					<th><?php esc_html_e( 'Status', 'auto-missing-featured-image' ); ?></th>
					<th><?php esc_html_e( 'Date', 'auto-missing-featured-image' ); ?></th>
					<th><?php esc_html_e( 'Result', 'auto-missing-featured-image' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'auto-missing-featured-image' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( $query->have_posts() ) : ?>
				<?php
				while ( $query->have_posts() ) :
					$query->the_post();
					$pid = get_the_ID();
					?>
					<tr data-post-id="<?php echo esc_attr( $pid ); ?>">
						<th class="check-column"><input type="checkbox" class="amfi-check" value="<?php echo esc_attr( $pid ); ?>"></th>
						<td><?php echo esc_html( $pid ); ?></td>
						<td>
							<a href="<?php echo esc_url( get_edit_post_link( $pid ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_the_title( $pid ) ); ?></a>
						</td>
						<td><?php echo esc_html( get_post_type( $pid ) ); ?></td>
						<td><?php echo esc_html( get_post_status( $pid ) ); ?></td>
						<td><?php echo esc_html( get_the_date( '', $pid ) ); ?></td>
						<td class="amfi-row-result">—</td>
						<td class="amfi-row-actions">
							<button type="button" class="button button-small amfi-find-btn" data-post-id="<?php echo esc_attr( $pid ); ?>" data-title="<?php echo esc_attr( get_the_title( $pid ) ); ?>"><?php esc_html_e( 'Find Images', 'auto-missing-featured-image' ); ?></button>
							<button type="button" class="button button-small amfi-auto-one" data-post-id="<?php echo esc_attr( $pid ); ?>"><?php esc_html_e( 'Auto Set', 'auto-missing-featured-image' ); ?></button>
						</td>
					</tr>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
			<?php else : ?>
				<tr><td colspan="8"><?php esc_html_e( 'Great! No posts are missing a featured image for these filters.', 'auto-missing-featured-image' ); ?></td></tr>
			<?php endif; ?>
			</tbody>
		</table>

		<?php
		$total_pages = (int) $query->max_num_pages;
		if ( $total_pages > 1 ) {
			$links = paginate_links(
				array(
					'base'      => add_query_arg(
						array(
							'page'       => self::MENU_SLUG,
							'tab'        => 'process',
							'amfi_ptype' => $filter_type,
							'amfi_s'     => $search,
							'amfi_paged' => '%#%',
						),
						admin_url( 'admin.php' )
					),
					'format'    => '',
					'current'   => $current_page,
					'total'     => $total_pages,
					'type'      => 'list',
				)
			);
			if ( $links ) {
				echo '<div class="amfi-pagination">' . wp_kses_post( $links ) . '</div>';
			}
		}
		?>

		<?php $this->render_modal(); ?>
		<?php
	}

	/**
	 * Manual image-picker modal markup.
	 */
	private function render_modal() {
		?>
		<div id="amfi-modal" class="amfi-modal" style="display:none;" role="dialog" aria-modal="true">
			<div class="amfi-modal-box">
				<div class="amfi-modal-head">
					<h2><?php esc_html_e( 'Choose a featured image', 'auto-missing-featured-image' ); ?> <span id="amfi-modal-for"></span></h2>
					<button type="button" class="amfi-modal-close" aria-label="<?php esc_attr_e( 'Close', 'auto-missing-featured-image' ); ?>">×</button>
				</div>
				<div class="amfi-modal-search">
					<input type="text" id="amfi-modal-query" class="regular-text" placeholder="<?php esc_attr_e( 'Search keywords e.g. laptop office desk', 'auto-missing-featured-image' ); ?>">
					<button type="button" class="button button-primary" id="amfi-modal-search"><?php esc_html_e( 'Search', 'auto-missing-featured-image' ); ?></button>
					<button type="button" class="button" id="amfi-modal-ai"><?php esc_html_e( 'AI Keywords (Groq)', 'auto-missing-featured-image' ); ?></button>
				</div>
				<p id="amfi-modal-status" class="description"></p>
				<div id="amfi-modal-results" class="amfi-grid"></div>
			</div>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* Settings tab                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * Settings tab.
	 */
	private function render_settings_tab() {
		$s = amfi_get_settings();
		?>
		<form method="post" action="options.php" class="amfi-settings-form">
			<?php settings_fields( 'amfi_settings_group' ); ?>

			<h2 class="amfi-section-title"><span class="amfi-section-num">1</span> <?php esc_html_e( 'Image API Keys (free)', 'auto-missing-featured-image' ); ?></h2>

			<div class="amfi-card amfi-keys-card">
				<h3 class="amfi-card-title">📸 <?php esc_html_e( 'Unsplash API Application', 'auto-missing-featured-image' ); ?></h3>
				<p class="description amfi-card-desc">
					<?php esc_html_e( 'Your Unsplash application page (unsplash.com/oauth/applications → your app) shows three values. Paste each one into its own field below, exactly as shown there — for searching photos the plugin uses the Access Key only (Authorization: Client-ID).', 'auto-missing-featured-image' ); ?>
				</p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amfi_unsplash_app_id"><?php esc_html_e( 'Application ID', 'auto-missing-featured-image' ); ?> <span class="amfi-badge amfi-badge-gray"><?php esc_html_e( 'Optional', 'auto-missing-featured-image' ); ?></span></label></th>
						<td>
							<input type="text" autocomplete="off" class="regular-text amfi-mono" id="amfi_unsplash_app_id" name="amfi_settings[unsplash_app_id]" value="<?php echo esc_attr( $s['unsplash_app_id'] ); ?>" placeholder="e.g. 123456">
							<p class="description"><?php esc_html_e( 'Only for your own reference. It is NOT used to search photos — never paste this into the Access Key field.', 'auto-missing-featured-image' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amfi_unsplash_key"><?php esc_html_e( 'Access Key', 'auto-missing-featured-image' ); ?> <span class="amfi-badge amfi-badge-green"><?php esc_html_e( 'Required for Unsplash', 'auto-missing-featured-image' ); ?></span></label></th>
						<td>
							<span class="amfi-key-field">
								<input type="password" autocomplete="off" class="regular-text amfi-mono" id="amfi_unsplash_key" name="amfi_settings[unsplash_key]" value="<?php echo esc_attr( $s['unsplash_key'] ); ?>" placeholder="<?php esc_attr_e( 'Paste the Access Key here', 'auto-missing-featured-image' ); ?>">
								<button type="button" class="button amfi-toggle-key" data-target="amfi_unsplash_key" aria-label="<?php esc_attr_e( 'Show or hide key', 'auto-missing-featured-image' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								<button type="button" class="button amfi-test-btn" data-service="unsplash" data-key-input="amfi_unsplash_key"><?php esc_html_e( 'Test Connection', 'auto-missing-featured-image' ); ?></button>
							</span>
							<span class="amfi-test-result" role="status"></span>
							<p class="description"><?php esc_html_e( 'This is the only Unsplash value used for searching. If the test says 401, you most likely pasted the Secret Key or Application ID by mistake.', 'auto-missing-featured-image' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="amfi_unsplash_secret"><?php esc_html_e( 'Secret Key', 'auto-missing-featured-image' ); ?> <span class="amfi-badge amfi-badge-gray"><?php esc_html_e( 'Optional', 'auto-missing-featured-image' ); ?></span></label></th>
						<td>
							<span class="amfi-key-field">
								<input type="password" autocomplete="off" class="regular-text amfi-mono" id="amfi_unsplash_secret" name="amfi_settings[unsplash_secret]" value="<?php echo esc_attr( $s['unsplash_secret'] ); ?>" placeholder="<?php esc_attr_e( 'Paste the Secret Key here (optional)', 'auto-missing-featured-image' ); ?>">
								<button type="button" class="button amfi-toggle-key" data-target="amfi_unsplash_secret" aria-label="<?php esc_attr_e( 'Show or hide key', 'auto-missing-featured-image' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
							</span>
							<p class="description"><?php esc_html_e( 'Not needed for searching photos (only for OAuth user-login flows). Stored securely in your database for future use. NEVER share this key with anyone or paste it anywhere public — if it leaks, regenerate it on Unsplash.', 'auto-missing-featured-image' ); ?></p>
						</td>
					</tr>
				</table>
			</div>

			<div class="amfi-card amfi-keys-card">
				<h3 class="amfi-card-title">🖼️ <?php esc_html_e( 'Pexels API', 'auto-missing-featured-image' ); ?></h3>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="amfi_pexels_key"><?php esc_html_e( 'Pexels API Key', 'auto-missing-featured-image' ); ?> <span class="amfi-badge amfi-badge-green"><?php esc_html_e( 'Required for Pexels', 'auto-missing-featured-image' ); ?></span></label></th>
						<td>
							<span class="amfi-key-field">
								<input type="password" autocomplete="off" class="regular-text amfi-mono" id="amfi_pexels_key" name="amfi_settings[pexels_key]" value="<?php echo esc_attr( $s['pexels_key'] ); ?>">
								<button type="button" class="button amfi-toggle-key" data-target="amfi_pexels_key" aria-label="<?php esc_attr_e( 'Show or hide key', 'auto-missing-featured-image' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								<button type="button" class="button amfi-test-btn" data-service="pexels" data-key-input="amfi_pexels_key"><?php esc_html_e( 'Test Connection', 'auto-missing-featured-image' ); ?></button>
							</span>
							<span class="amfi-test-result" role="status"></span>
							<p class="description"><?php esc_html_e( 'Free at pexels.com/api → Your API Key.', 'auto-missing-featured-image' ); ?></p>
						</td>
					</tr>
				</table>
			</div>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="amfi_source_priority"><?php esc_html_e( 'Image source', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<select id="amfi_source_priority" name="amfi_settings[source_priority]">
							<option value="unsplash_then_pexels" <?php selected( $s['source_priority'], 'unsplash_then_pexels' ); ?>><?php esc_html_e( 'Unsplash first, then Pexels', 'auto-missing-featured-image' ); ?></option>
							<option value="pexels_then_unsplash" <?php selected( $s['source_priority'], 'pexels_then_unsplash' ); ?>><?php esc_html_e( 'Pexels first, then Unsplash', 'auto-missing-featured-image' ); ?></option>
							<option value="unsplash_only" <?php selected( $s['source_priority'], 'unsplash_only' ); ?>><?php esc_html_e( 'Unsplash only', 'auto-missing-featured-image' ); ?></option>
							<option value="pexels_only" <?php selected( $s['source_priority'], 'pexels_only' ); ?>><?php esc_html_e( 'Pexels only', 'auto-missing-featured-image' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Tip: add both free keys. If the first source finds nothing (or its hourly limit is reached), the second is tried automatically.', 'auto-missing-featured-image' ); ?></p>
					</td>
				</tr>
			</table>

			<h2 class="amfi-section-title"><span class="amfi-section-num">2</span> <?php esc_html_e( 'Image customization', 'auto-missing-featured-image' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="amfi_quality"><?php esc_html_e( 'Image quality / size', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<select id="amfi_quality" name="amfi_settings[quality]">
							<option value="small" <?php selected( $s['quality'], 'small' ); ?>><?php esc_html_e( 'Small (~400px)', 'auto-missing-featured-image' ); ?></option>
							<option value="medium" <?php selected( $s['quality'], 'medium' ); ?>><?php esc_html_e( 'Medium (~1000px) – Recommended', 'auto-missing-featured-image' ); ?></option>
							<option value="large" <?php selected( $s['quality'], 'large' ); ?>><?php esc_html_e( 'Large (full width)', 'auto-missing-featured-image' ); ?></option>
							<option value="original" <?php selected( $s['quality'], 'original' ); ?>><?php esc_html_e( 'Original (largest, slow)', 'auto-missing-featured-image' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_orientation"><?php esc_html_e( 'Orientation', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<select id="amfi_orientation" name="amfi_settings[orientation]">
							<option value="landscape" <?php selected( $s['orientation'], 'landscape' ); ?>><?php esc_html_e( 'Landscape (wide) – best for blogs', 'auto-missing-featured-image' ); ?></option>
							<option value="portrait" <?php selected( $s['orientation'], 'portrait' ); ?>><?php esc_html_e( 'Portrait (tall)', 'auto-missing-featured-image' ); ?></option>
							<option value="squarish" <?php selected( $s['orientation'], 'squarish' ); ?>><?php esc_html_e( 'Square', 'auto-missing-featured-image' ); ?></option>
							<option value="any" <?php selected( $s['orientation'], 'any' ); ?>><?php esc_html_e( 'Any', 'auto-missing-featured-image' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_query_source"><?php esc_html_e( 'Build search query from', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<select id="amfi_query_source" name="amfi_settings[query_source]">
							<option value="title" <?php selected( $s['query_source'], 'title' ); ?>><?php esc_html_e( 'Post title only', 'auto-missing-featured-image' ); ?></option>
							<option value="title_terms" <?php selected( $s['query_source'], 'title_terms' ); ?>><?php esc_html_e( 'Title + first category & tag', 'auto-missing-featured-image' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_extra_keywords"><?php esc_html_e( 'Extra keywords for every search', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="amfi_extra_keywords" name="amfi_settings[extra_keywords]" value="<?php echo esc_attr( $s['extra_keywords'] ); ?>" placeholder="e.g. technology office">
						<p class="description"><?php esc_html_e( 'Optional. Your niche keywords, appended to every image search.', 'auto-missing-featured-image' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_fallback_query"><?php esc_html_e( 'Fallback search when nothing matches', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="amfi_fallback_query" name="amfi_settings[fallback_query]" value="<?php echo esc_attr( $s['fallback_query'] ); ?>" placeholder="e.g. blogging laptop writing">
						<p class="description"><?php esc_html_e( 'Optional. If a title matches no photo, this query is used instead (images are rotated so posts do not all get the same photo).', 'auto-missing-featured-image' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Attachment options', 'auto-missing-featured-image' ); ?></th>
					<td>
						<label><input type="checkbox" name="amfi_settings[set_alt_text]" value="1" <?php checked( $s['set_alt_text'], 1 ); ?>> <?php esc_html_e( 'Set alt text automatically (SEO)', 'auto-missing-featured-image' ); ?></label><br>
						<label><input type="checkbox" name="amfi_settings[add_credit]" value="1" <?php checked( $s['add_credit'], 1 ); ?>> <?php esc_html_e( 'Add photographer credit in image caption', 'auto-missing-featured-image' ); ?></label><br>
						<label><input type="checkbox" name="amfi_settings[only_missing]" value="1" <?php checked( $s['only_missing'], 1 ); ?>> <?php esc_html_e( 'Only process posts that are missing a featured image (never overwrite)', 'auto-missing-featured-image' ); ?></label>
					</td>
				</tr>
			</table>

			<h2 class="amfi-section-title"><span class="amfi-section-num">3</span> <?php esc_html_e( 'Groq AI – smart keywords (optional but powerful)', 'auto-missing-featured-image' ); ?></h2>
			<p class="description" style="max-width:720px;"><?php esc_html_e( 'Groq AI does not generate images. It reads the post title/excerpt (Hindi titles included) and returns the best 2–5 English search keywords, one request per post during batch processing. This massively improves matches when a raw title search finds nothing.', 'auto-missing-featured-image' ); ?></p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="amfi_groq_key"><?php esc_html_e( 'Groq API Key', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<span class="amfi-key-field">
							<input type="password" autocomplete="off" class="regular-text amfi-mono" id="amfi_groq_key" name="amfi_settings[groq_key]" value="<?php echo esc_attr( $s['groq_key'] ); ?>" placeholder="gsk_…">
							<button type="button" class="button amfi-toggle-key" data-target="amfi_groq_key" aria-label="<?php esc_attr_e( 'Show or hide key', 'auto-missing-featured-image' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
							<button type="button" class="button amfi-test-btn" data-service="groq" data-key-input="amfi_groq_key" data-model-input="amfi_groq_model"><?php esc_html_e( 'Test Connection', 'auto-missing-featured-image' ); ?></button>
						</span>
						<span class="amfi-test-result" role="status"></span>
						<p class="description">
							<?php esc_html_e( 'Free key:', 'auto-missing-featured-image' ); ?>
							<a href="https://console.groq.com/keys" target="_blank" rel="noopener noreferrer">console.groq.com/keys</a> →
							<?php esc_html_e( 'Create API Key (starts with "gsk_"). Docs:', 'auto-missing-featured-image' ); ?>
							<a href="https://console.groq.com/docs" target="_blank" rel="noopener noreferrer">console.groq.com/docs</a>.
							<?php esc_html_e( 'Keep this key private — never share it publicly; if it leaks, delete it in the Groq console and create a new one.', 'auto-missing-featured-image' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_groq_mode"><?php esc_html_e( 'When to use Groq AI', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<select id="amfi_groq_mode" name="amfi_settings[groq_mode]">
							<option value="off" <?php selected( $s['groq_mode'], 'off' ); ?>><?php esc_html_e( 'Off', 'auto-missing-featured-image' ); ?></option>
							<option value="fallback" <?php selected( $s['groq_mode'], 'fallback' ); ?>><?php esc_html_e( 'Fallback only – when title search finds nothing (Recommended, saves quota)', 'auto-missing-featured-image' ); ?></option>
							<option value="always" <?php selected( $s['groq_mode'], 'always' ); ?>><?php esc_html_e( 'Always – AI keywords first for every post (best for Hindi/non-English titles)', 'auto-missing-featured-image' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_groq_model"><?php esc_html_e( 'Groq model', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<input type="text" class="regular-text amfi-mono" id="amfi_groq_model" name="amfi_settings[groq_model]" value="<?php echo esc_attr( $s['groq_model'] ); ?>" list="amfi_groq_models">
						<datalist id="amfi_groq_models">
							<option value="llama-3.3-70b-versatile"></option>
							<option value="llama-3.1-8b-instant"></option>
							<option value="openai/gpt-oss-120b"></option>
							<option value="openai/gpt-oss-20b"></option>
							<option value="meta-llama/llama-4-scout-17b-16e-instruct"></option>
						</datalist>
						<p class="description">
							<?php esc_html_e( 'Default: llama-3.3-70b-versatile (best quality). Fastest: llama-3.1-8b-instant. You can type any model ID — full current list:', 'auto-missing-featured-image' ); ?>
							<a href="https://console.groq.com/docs/models" target="_blank" rel="noopener noreferrer">console.groq.com/docs/models</a>
						</p>
					</td>
				</tr>
			</table>

			<h2 class="amfi-section-title"><span class="amfi-section-num">4</span> <?php esc_html_e( 'Grok (xAI) AI image generation – last resort (optional)', 'auto-missing-featured-image' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable AI generation', 'auto-missing-featured-image' ); ?></th>
					<td>
						<label><input type="checkbox" name="amfi_settings[ai_generate_fallback]" value="1" <?php checked( $s['ai_generate_fallback'], 1 ); ?>> <?php esc_html_e( 'If no stock photo is found at all, generate one with Grok (xAI)', 'auto-missing-featured-image' ); ?></label>
						<p class="description"><?php esc_html_e( 'Requires a paid xAI API key (starts with "xai-") from console.x.ai. This is different from a Groq "gsk-" key.', 'auto-missing-featured-image' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_xai_key"><?php esc_html_e( 'xAI API Key', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<span class="amfi-key-field">
							<input type="password" autocomplete="off" class="regular-text amfi-mono" id="amfi_xai_key" name="amfi_settings[xai_key]" value="<?php echo esc_attr( $s['xai_key'] ); ?>" placeholder="xai-…">
							<button type="button" class="button amfi-toggle-key" data-target="amfi_xai_key" aria-label="<?php esc_attr_e( 'Show or hide key', 'auto-missing-featured-image' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
						</span>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_xai_model"><?php esc_html_e( 'xAI image model', 'auto-missing-featured-image' ); ?></label></th>
					<td><input type="text" class="regular-text" id="amfi_xai_model" name="amfi_settings[xai_model]" value="<?php echo esc_attr( $s['xai_model'] ); ?>"></td>
				</tr>
			</table>

			<h2 class="amfi-section-title"><span class="amfi-section-num">5</span> <?php esc_html_e( 'Which posts to process', 'auto-missing-featured-image' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Post types', 'auto-missing-featured-image' ); ?></th>
					<td>
						<?php
						$all_types = get_post_types( array( 'public' => true ), 'objects' );
						unset( $all_types['attachment'] );
						foreach ( $all_types as $slug => $obj ) :
							?>
							<label style="display:inline-block;min-width:180px;">
								<input type="checkbox" name="amfi_settings[post_types][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, (array) $s['post_types'], true ) ); ?>>
								<?php echo esc_html( $obj->labels->name . ' (' . $slug . ')' ); ?>
							</label>
						<?php endforeach; ?>
						<p class="description"><?php esc_html_e( 'Works with any post type that supports featured images — posts, pages, WooCommerce products, custom post types, etc.', 'auto-missing-featured-image' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Post statuses', 'auto-missing-featured-image' ); ?></th>
					<td>
						<?php foreach ( array( 'publish', 'future', 'draft', 'pending', 'private' ) as $status ) : ?>
							<label style="display:inline-block;min-width:120px;">
								<input type="checkbox" name="amfi_settings[post_status][]" value="<?php echo esc_attr( $status ); ?>" <?php checked( in_array( $status, (array) $s['post_status'], true ) ); ?>>
								<?php echo esc_html( ucfirst( $status ) ); ?>
							</label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="amfi_batch_size"><?php esc_html_e( 'Posts per page / batch', 'auto-missing-featured-image' ); ?></label></th>
					<td>
						<input type="number" min="1" max="100" id="amfi_batch_size" name="amfi_settings[batch_size]" value="<?php echo esc_attr( (int) $s['batch_size'] ); ?>">
						<p class="description"><?php esc_html_e( 'Batch processing always runs one post at a time in your browser, so it never overloads the server. This controls how many rows are listed per page.', 'auto-missing-featured-image' ); ?></p>
					</td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Help tab.
	 */
	private function render_help_tab() {
		?>
		<div class="amfi-help" style="max-width:820px;">
			<h2><?php esc_html_e( 'How it works', 'auto-missing-featured-image' ); ?></h2>
			<ol>
				<li><?php esc_html_e( 'Add your free Unsplash and/or Pexels API keys in Settings.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Open "Scan & Process" — all posts missing a featured image are listed.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Select posts and click the batch button, OR click "Find Images" on any row to manually pick from search results, OR click "Auto Set" for a single post.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'The chosen image is downloaded into your Media Library (not hotlinked) and set as the featured image, with alt text and photographer credit.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'You can also search from the post editor: look for the "Find Featured Image" box in the sidebar.', 'auto-missing-featured-image' ); ?></li>
			</ol>

			<h2><?php esc_html_e( 'Get a free Unsplash key', 'auto-missing-featured-image' ); ?></h2>
			<ol>
				<li><?php esc_html_e( 'Go to unsplash.com/developers and create an account / log in.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Click "New Application", accept the terms, give it any name.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Open your application page. It shows three values: Application ID, Access Key and Secret Key. In this plugin\'s Settings there is one field for each — paste them exactly as shown.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'For searching photos only the ACCESS KEY is used (sent as "Authorization: Client-ID"). The Secret Key is only for OAuth user-login flows, and the Application ID is just a reference number. If Unsplash returns 401 errors, the Secret Key or Application ID was probably pasted into the Access Key field.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Click "Test Connection" next to the Access Key to verify it instantly, then Save.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Demo apps allow about 50 requests/hour — enough for ~50 posts/hour. Apply for production access on Unsplash for higher limits.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Keep the Secret Key confidential. If you ever shared it publicly (chat, screenshot, repo), regenerate your keys from the application page.', 'auto-missing-featured-image' ); ?></li>
			</ol>

			<h2><?php esc_html_e( 'Get a free Pexels key', 'auto-missing-featured-image' ); ?></h2>
			<ol>
				<li><?php esc_html_e( 'Go to pexels.com/api and sign up.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Open "Your API Key" and copy the key into Settings.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'The free tier allows about 200 requests/hour.', 'auto-missing-featured-image' ); ?></li>
			</ol>

			<h2><?php esc_html_e( 'Get a free Groq AI key', 'auto-missing-featured-image' ); ?></h2>
			<ol>
				<li>
					<?php esc_html_e( 'Go to', 'auto-missing-featured-image' ); ?>
					<a href="https://console.groq.com/keys" target="_blank" rel="noopener noreferrer">console.groq.com/keys</a>
					<?php esc_html_e( 'and sign in.', 'auto-missing-featured-image' ); ?>
				</li>
				<li><?php esc_html_e( 'Create API Key. The key starts with "gsk_". Paste it in Settings and click "Test Connection" (this checks the key and your selected model via the models endpoint, without using chat tokens).', 'auto-missing-featured-image' ); ?></li>
				<li>
					<?php esc_html_e( 'This plugin calls the official OpenAI-compatible endpoint https://api.groq.com/openai/v1/chat/completions with your key as a Bearer token, exactly as documented at', 'auto-missing-featured-image' ); ?>
					<a href="https://console.groq.com/docs" target="_blank" rel="noopener noreferrer">console.groq.com/docs</a>.
					<?php esc_html_e( 'For the current model list see', 'auto-missing-featured-image' ); ?>
					<a href="https://console.groq.com/docs/models" target="_blank" rel="noopener noreferrer">console.groq.com/docs/models</a>.
				</li>
				<li><?php esc_html_e( 'Never share this key in public or commit it to a repository — anyone could use your quota. If a key leaks, delete it in the Groq console and create a new one.', 'auto-missing-featured-image' ); ?></li>
			</ol>

			<h2><?php esc_html_e( 'Tips', 'auto-missing-featured-image' ); ?></h2>
			<ul>
				<li><?php esc_html_e( 'Hindi or other non-English titles? Set Groq AI mode to "Always" — it converts titles to English stock keywords automatically.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Add both Unsplash and Pexels keys: when one hits its hourly limit, the other keeps the batch going.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'If a batch shows API errors about rate limits, wait an hour or switch the source priority and run again — already-processed posts are automatically skipped.', 'auto-missing-featured-image' ); ?></li>
				<li><?php esc_html_e( 'Always take a backup before running a huge batch, although existing featured images are never overwritten by default.', 'auto-missing-featured-image' ); ?></li>
			</ul>

			<h2><?php esc_html_e( 'External services & privacy', 'auto-missing-featured-image' ); ?></h2>
			<p><?php esc_html_e( 'This plugin only contacts external services when an admin runs a search or batch, and only for the services whose API keys are provided:', 'auto-missing-featured-image' ); ?></p>
			<ul>
				<li><strong>Unsplash API</strong> — <?php esc_html_e( 'receives only the search query. Terms: unsplash.com/terms · Privacy: unsplash.com/privacy', 'auto-missing-featured-image' ); ?></li>
				<li><strong>Pexels API</strong> — <?php esc_html_e( 'receives only the search query. Terms: pexels.com/terms-of-service · Privacy: pexels.com/privacy-policy', 'auto-missing-featured-image' ); ?></li>
				<li><strong>Groq AI (optional)</strong> — <?php esc_html_e( 'receives the post title, a short excerpt and category/tag names to suggest search keywords. Terms: groq.com/terms-of-service · Privacy: groq.com/privacy-policy', 'auto-missing-featured-image' ); ?></li>
				<li><strong>xAI / Grok (optional)</strong> — <?php esc_html_e( 'receives a short image prompt derived from the post title. Terms: x.ai/legal/terms-of-service · Privacy: x.ai/legal/privacy-policy', 'auto-missing-featured-image' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* Post editor meta box                                                */
	/* ------------------------------------------------------------------ */

	/**
	 * Register the meta box on all selected post types.
	 */
	public function add_meta_box() {
		$settings = amfi_get_settings();
		foreach ( (array) $settings['post_types'] as $type ) {
			add_meta_box(
				'amfi_finder_box',
				__( 'Find Featured Image (Unsplash / Pexels)', 'auto-missing-featured-image' ),
				array( $this, 'render_meta_box' ),
				$type,
				'side',
				'low'
			);
		}
	}

	/**
	 * Render the meta box.
	 *
	 * @param WP_Post $post Current post.
	 */
	public function render_meta_box( $post ) {
		?>
		<div class="amfi-metabox" data-post-id="<?php echo esc_attr( $post->ID ); ?>">
			<p>
				<input type="text" class="amfi-metabox-query" style="width:100%;" value="<?php echo esc_attr( get_the_title( $post ) ); ?>" placeholder="<?php esc_attr_e( 'Search keywords', 'auto-missing-featured-image' ); ?>">
			</p>
			<p>
				<button type="button" class="button amfi-metabox-search"><?php esc_html_e( 'Search Images', 'auto-missing-featured-image' ); ?></button>
				<button type="button" class="button amfi-metabox-ai"><?php esc_html_e( 'AI Keywords', 'auto-missing-featured-image' ); ?></button>
				<button type="button" class="button amfi-metabox-auto"><?php esc_html_e( 'Auto Set', 'auto-missing-featured-image' ); ?></button>
			</p>
			<p class="amfi-metabox-status description"></p>
			<div class="amfi-metabox-results amfi-grid amfi-grid-small"></div>
			<p class="description"><?php esc_html_e( 'Click an image to set it as the featured image. The page will reload.', 'auto-missing-featured-image' ); ?></p>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* AJAX handlers                                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * Verify nonce + capability for an AJAX request about a post.
	 *
	 * @param int $post_id Post ID (0 = no specific post).
	 */
	private function ajax_guard( $post_id = 0 ) {
		check_ajax_referer( 'amfi_ajax' );

		if ( $post_id > 0 ) {
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'auto-missing-featured-image' ) ), 403 );
			}
		} elseif ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'auto-missing-featured-image' ) ), 403 );
		}
	}

	/**
	 * Sanitize a POST field.
	 *
	 * @param string $key     Field key.
	 * @param string $default Default value.
	 * @return string
	 */
	private function post_field( $key, $default = '' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verified in ajax_guard().
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : $default;
	}

	/**
	 * AJAX: search stock images (manual picker).
	 */
	public function ajax_search_images() {
		$post_id = absint( $this->post_field( 'post_id', '0' ) );
		$this->ajax_guard( $post_id );

		$settings = amfi_get_settings();
		$query    = $this->post_field( 'query' );
		$use_ai   = ( '1' === $this->post_field( 'use_ai' ) );

		if ( $use_ai && $post_id > 0 ) {
			$post     = get_post( $post_id );
			$ai_query = $post ? AMFI_API::Groq_optimize_query( $post, $settings ) : new WP_Error( 'amfi_no_post', __( 'Post not found.', 'auto-missing-featured-image' ) );
			if ( is_wp_error( $ai_query ) ) {
				wp_send_json_error( array( 'message' => $ai_query->get_error_message() ) );
			}
			$query = $ai_query;
		}

		if ( '' === $query && $post_id > 0 ) {
			$query = AMFI_Processor::build_title_query( get_post( $post_id ), $settings );
		}

		$items = AMFI_API::search_stock( $query, $settings, 9, true );
		if ( is_wp_error( $items ) ) {
			wp_send_json_error( array( 'message' => $items->get_error_message() ) );
		}

		// Long queries (full titles) often return nothing: retry with the first 5 words.
		if ( empty( $items ) ) {
			$words = preg_split( '/\s+/', $query );
			if ( is_array( $words ) && count( $words ) > 5 ) {
				$short  = implode( ' ', array_slice( $words, 0, 5 ) );
				$retry  = AMFI_API::search_stock( $short, $settings, 9, true );
				if ( ! is_wp_error( $retry ) && ! empty( $retry ) ) {
					$items = $retry;
					$query = $short;
				}
			}
		}

		wp_send_json_success(
			array(
				'query' => $query,
				'items' => $items,
			)
		);
	}

	/**
	 * AJAX: process one post automatically (batch step / Auto Set buttons).
	 */
	public function ajax_process_one() {
		$post_id = absint( $this->post_field( 'post_id', '0' ) );
		$this->ajax_guard( $post_id );

		if ( 0 === $post_id || ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied or invalid post.', 'auto-missing-featured-image' ) ), 403 );
		}

		$result              = AMFI_Processor::process_one( $post_id, amfi_get_settings() );
		$result['post_title'] = get_the_title( $post_id );

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: set a specific image (clicked in the manual picker).
	 */
	public function ajax_set_from_url() {
		$post_id = absint( $this->post_field( 'post_id', '0' ) );
		$this->ajax_guard( $post_id );

		if ( 0 === $post_id || ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied or invalid post.', 'auto-missing-featured-image' ) ), 403 );
		}

		$item = array(
			'source'            => sanitize_key( $this->post_field( 'source', 'unsplash' ) ),
			'full_url'          => esc_url_raw( $this->post_field( 'full_url' ) ),
			'alt'               => $this->post_field( 'alt' ),
			'photographer'      => $this->post_field( 'photographer' ),
			'photographer_url'  => esc_url_raw( $this->post_field( 'photographer_url' ) ),
			'page_url'          => esc_url_raw( $this->post_field( 'page_url' ) ),
			'download_location' => esc_url_raw( $this->post_field( 'download_location' ) ),
		);

		$set = AMFI_Processor::sideload_and_set( $post_id, $item, amfi_get_settings() );
		if ( is_wp_error( $set ) ) {
			wp_send_json_error( array( 'message' => $set->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'attachment_id' => (int) $set,
				'image_url'     => (string) wp_get_attachment_image_url( $set, 'medium' ),
				'message'       => __( 'Featured image set.', 'auto-missing-featured-image' ),
			)
		);
	}

	/**
	 * AJAX: ask Groq AI for keywords for one post.
	 */
	public function ajax_ai_query() {
		$post_id = absint( $this->post_field( 'post_id', '0' ) );
		$this->ajax_guard( $post_id );

		$post = get_post( $post_id );
		if ( ! $post ) {
			wp_send_json_error( array( 'message' => __( 'Post not found.', 'auto-missing-featured-image' ) ) );
		}

		$query = AMFI_API::Groq_optimize_query( $post, amfi_get_settings() );
		if ( is_wp_error( $query ) ) {
			wp_send_json_error( array( 'message' => $query->get_error_message() ) );
		}

		wp_send_json_success( array( 'query' => $query ) );
	}

	/**
	 * AJAX: test an API key (Settings "Test Connection" buttons).
	 *
	 * Tests the key currently typed in the form — even before saving —
	 * so the admin can immediately see whether e.g. the Unsplash
	 * Access Key (not the Secret Key / Application ID) was pasted.
	 * Requires manage_options because API keys are involved.
	 */
	public function ajax_test_connection() {
		check_ajax_referer( 'amfi_ajax' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'auto-missing-featured-image' ) ), 403 );
		}

		$service   = sanitize_key( $this->post_field( 'service' ) );
		$typed_key = trim( $this->post_field( 'api_key' ) );
		$settings  = amfi_get_settings();

		switch ( $service ) {
			case 'unsplash':
				$key    = '' !== $typed_key ? $typed_key : (string) $settings['unsplash_key'];
				$result = AMFI_API::test_unsplash( $key );
				break;

			case 'pexels':
				$key    = '' !== $typed_key ? $typed_key : (string) $settings['pexels_key'];
				$result = AMFI_API::test_pexels( $key );
				break;

			case 'groq':
				$key   = '' !== $typed_key ? $typed_key : (string) $settings['groq_key'];
				$model = trim( $this->post_field( 'model' ) );
				if ( '' === $model ) {
					$model = (string) $settings['groq_model'];
				}
				$result = AMFI_API::test_groq( $key, $model );
				break;

			default:
				wp_send_json_error( array( 'message' => __( 'Unknown service.', 'auto-missing-featured-image' ) ) );
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => $result['message'] ) );
	}
}
