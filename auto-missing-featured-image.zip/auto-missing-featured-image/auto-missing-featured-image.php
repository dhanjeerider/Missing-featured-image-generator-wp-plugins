<?php
/**
 * Plugin Name:       Auto Missing Featured Image – Unsplash, Pexels & AI
 * Plugin URI:        https://wordpress.org/plugins/auto-missing-featured-image/
 * Description:       Finds posts, pages and custom post types that are missing a featured image and automatically sets one from Unsplash or Pexels based on the title. Includes optional Groq AI keyword optimization and optional Grok (xAI) image generation fallback.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Your Name
 * Author URI:        https://example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       auto-missing-featured-image
 * Domain Path:       /languages
 *
 * @package Auto_Missing_Featured_Image
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AMFI_VERSION', '1.1.0' );
define( 'AMFI_FILE', __FILE__ );
define( 'AMFI_DIR', plugin_dir_path( __FILE__ ) );
define( 'AMFI_URL', plugin_dir_url( __FILE__ ) );

require_once AMFI_DIR . 'includes/class-amfi-api.php';
require_once AMFI_DIR . 'includes/class-amfi-processor.php';

if ( is_admin() ) {
	require_once AMFI_DIR . 'includes/class-amfi-admin.php';
}

/**
 * Default plugin settings.
 *
 * NOTE (WordPress.org SVN friendly): No API key is hardcoded in this plugin.
 * Keys are stored only in the site's own options table, entered by the
 * site admin on the Settings tab. Hardcoding a shared key would leak it
 * to every install and is not allowed in the wordpress.org repository.
 *
 * @return array
 */
function amfi_default_settings() {
	return array(
		// API keys (entered by the site admin, never shipped in code).
		// Unsplash: only the Access Key is used for searching (Client-ID auth).
		// Application ID is informational; the Secret Key is only needed for
		// OAuth user flows and is stored but not used for public search.
		'unsplash_app_id'     => '',
		'unsplash_key'        => '', // Unsplash Access Key.
		'unsplash_secret'     => '', // Unsplash Secret Key (optional).
		'pexels_key'          => '',
		'groq_key'            => '',
		'xai_key'             => '',

		// Sources & search behaviour.
		'source_priority'     => 'unsplash_then_pexels', // unsplash_then_pexels|pexels_then_unsplash|unsplash_only|pexels_only.
		'quality'             => 'medium',               // small|medium|large|original.
		'orientation'         => 'landscape',            // any|landscape|portrait|squarish.
		'query_source'        => 'title',                // title|title_terms.
		'extra_keywords'      => '',                     // Appended to every stock search, e.g. your niche.
		'fallback_query'      => '',                     // Used when nothing matches the title, e.g. "technology blog".

		// Groq AI keyword optimization.
		'groq_mode'           => 'fallback',             // off|always|fallback.
		'groq_model'          => 'llama-3.3-70b-versatile',

		// Optional Grok (xAI) image generation, used only when stock search finds nothing.
		'ai_generate_fallback' => 0,
		'xai_model'           => 'grok-2-image-1212',

		// Scope.
		'post_types'          => array( 'post', 'page' ),
		'post_status'         => array( 'publish', 'draft' ),
		'batch_size'          => 20,
		'only_missing'        => 1,

		// Attachment options.
		'set_alt_text'        => 1,
		'add_credit'          => 1,
	);
}

/**
 * Get merged plugin settings.
 *
 * @return array
 */
function amfi_get_settings() {
	$saved = get_option( 'amfi_settings', array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	return array_merge( amfi_default_settings(), $saved );
}

/**
 * Load the plugin text domain.
 */
function amfi_load_textdomain() {
	load_plugin_textdomain( 'auto-missing-featured-image', false, dirname( plugin_basename( AMFI_FILE ) ) . '/languages' );
}
add_action( 'init', 'amfi_load_textdomain' );

/**
 * Activation: store defaults if nothing is saved yet.
 */
function amfi_activate() {
	if ( false === get_option( 'amfi_settings', false ) ) {
		add_option( 'amfi_settings', amfi_default_settings() );
	}
}
register_activation_hook( AMFI_FILE, 'amfi_activate' );

/**
 * Boot the admin UI.
 */
function amfi_boot_admin() {
	if ( is_admin() && class_exists( 'AMFI_Admin' ) ) {
		new AMFI_Admin();
	}
}
add_action( 'plugins_loaded', 'amfi_boot_admin' );
